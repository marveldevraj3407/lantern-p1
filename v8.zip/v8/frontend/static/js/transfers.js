/**
 * Transfers manager, progress visualization, incoming modal, and research metrics.
 */

const TransfersModule = {
  activeJobs: {}, // transfer_id -> job data
  pendingIncomingRequests: [],
  historySortBy: "date",
  historySortOrder: "desc",

  init() {
    this.bindEvents();
    this.setupSSEListeners();
    this.renderActiveTransfers();
    this.updateSortHeaderIndicators();
    this.refreshHistory();
    this.refreshDownloadedFiles();

    if (window.location.search.includes("demo=requests")) {
      setTimeout(async () => {
        try {
          await fetch("/api/test/mock_incoming", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              transfer_id: "tx-alice-1",
              sender: { username: "Alice", hostname: "ALICE-PC", ip: "192.168.1.101" },
              item_name: "Research_Project_Report_Final.pdf",
              is_folder: false,
              total_bytes: 14500000,
            }),
          });
          await new Promise((r) => setTimeout(r, 200));
          await fetch("/api/test/mock_incoming", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              transfer_id: "tx-bob-2",
              sender: { username: "Bob", hostname: "BOB-WORKSTATION", ip: "192.168.1.102" },
              item_name: "Design_Assets_2026.zip",
              is_folder: false,
              total_bytes: 84200000,
            }),
          });
          await new Promise((r) => setTimeout(r, 200));
          await fetch("/api/test/mock_incoming", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              transfer_id: "tx-charlie-3",
              sender: { username: "Charlie", hostname: "CHARLIE-MAC", ip: "192.168.1.103" },
              item_name: "Project_Source_Code",
              is_folder: true,
              total_bytes: 4200000,
            }),
          });
        } catch (err) {
          console.error("Demo trigger failed:", err);
        }
      }, 500);
    }
  },

  bindEvents() {
    const searchHistoryInput = document.getElementById("search-history-input");
    if (searchHistoryInput) {
      searchHistoryInput.addEventListener("input", () => this.refreshHistory());
    }

    const filterDirection = document.getElementById("filter-direction-select");
    if (filterDirection) {
      filterDirection.addEventListener("change", () => this.refreshHistory());
    }

    const filterStatus = document.getElementById("filter-status-select");
    if (filterStatus) {
      filterStatus.addEventListener("change", () => this.refreshHistory());
    }

    const sortHistorySelect = document.getElementById("sort-history-select");
    if (sortHistorySelect) {
      sortHistorySelect.addEventListener("change", (e) => {
        const val = e.target.value;
        const parts = val.split("_");
        this.historySortBy = parts[0] || "date";
        this.historySortOrder = parts[1] || "desc";
        this.updateSortHeaderIndicators();
        this.refreshHistory();
      });
    }

    // Clickable table header sorting
    document.querySelectorAll(".sortable-th").forEach((th) => {
      th.addEventListener("click", () => {
        const sortKey = th.getAttribute("data-sort");
        if (!sortKey) return;
        if (this.historySortBy === sortKey) {
          this.historySortOrder = this.historySortOrder === "asc" ? "desc" : "asc";
        } else {
          this.historySortBy = sortKey;
          this.historySortOrder = (sortKey === "date" || sortKey === "speed") ? "desc" : "asc";
        }
        if (sortHistorySelect) {
          const candidateVal = `${this.historySortBy}_${this.historySortOrder}`;
          if (Array.from(sortHistorySelect.options).some((opt) => opt.value === candidateVal)) {
            sortHistorySelect.value = candidateVal;
          }
        }
        this.updateSortHeaderIndicators();
        this.refreshHistory();
      });
    });

    const searchFilesInput = document.getElementById("search-files-input");
    if (searchFilesInput) {
      searchFilesInput.addEventListener("input", () => this.refreshDownloadedFiles());
    }
  },

  setupSSEListeners() {
    // 1. Incoming transfer request (stack notification on bottom right)
    API.on("INCOMING_TRANSFER_REQUEST", (req) => {
      const idx = this.pendingIncomingRequests.findIndex((r) => r.transfer_id === req.transfer_id);
      if (idx >= 0) {
        this.pendingIncomingRequests[idx] = req;
      } else {
        this.pendingIncomingRequests.push(req);
      }
      this.updateIncomingBadge();
      this.renderIncomingStack();
    });

    // 2. Transfer started
    API.on("TRANSFER_STARTED", (data) => {
      this.activeJobs[data.transfer_id] = {
        id: data.transfer_id,
        direction: data.direction,
        name: data.item_name,
        peer_username: data.peer_username || "Peer",
        total_bytes: data.total_bytes,
        transferred_bytes: 0,
        percent: 0,
        speed_mbps: 0,
        eta_seconds: 0,
        priority: (data.priority || "MEDIUM").toUpperCase(),
        status: "IN_PROGRESS",
      };
      this.renderActiveTransfers();

      // Only notify for accept: Inform sender that recipient accepted their transfer request
      if (data.direction === "OUTGOING") {
        showToast(
          `${data.peer_username || "Recipient"} accepted transfer of ${data.item_name || "file"}`,
          "success"
        );
      }
    });

    // 3. Transfer progress
    API.on("TRANSFER_PROGRESS", (data) => {
      if (!this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id] = { id: data.transfer_id };
      }
      Object.assign(this.activeJobs[data.transfer_id], data);
      this.renderActiveTransfers();
    });

    // 4. Transfer completed
    API.on("TRANSFER_COMPLETED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "COMPLETED";
        this.activeJobs[data.transfer_id].percent = 100;
      }
      this.renderActiveTransfers();
      this.refreshHistory();
      this.refreshDownloadedFiles();
    });

    // 5. Transfer failed
    API.on("TRANSFER_FAILED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "FAILED";
        this.activeJobs[data.transfer_id].error = data.error;
      }
      this.renderActiveTransfers();
      this.refreshHistory();
    });

    // 6. Transfer rejected (notify sender that recipient rejected request)
    API.on("TRANSFER_REJECTED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "REJECTED";
      }
      this.renderActiveTransfers();
      this.refreshHistory();
      showToast(`Recipient rejected transfer: ${data.reason || "Declined"}`, "warning");
    });

    // 7. Dynamic priority updated (Free Download Manager style)
    API.on("TRANSFER_PRIORITY_UPDATED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].priority = (data.priority || "MEDIUM").toUpperCase();
        this.renderActiveTransfers();
      }
    });

    // 8. Transfer paused
    API.on("TRANSFER_PAUSED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "PAUSED";
        this.renderActiveTransfers();
      }
    });

    // 9. Transfer resumed
    API.on("TRANSFER_RESUMED", (data) => {
      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "IN_PROGRESS";
        this.renderActiveTransfers();
      }
    });

    // 10. Transfer cancelled
    API.on("TRANSFER_CANCELLED", (data) => {
      this.removeIncomingCard(data.transfer_id);
      this.pendingIncomingRequests = this.pendingIncomingRequests.filter(
        (r) => r.transfer_id !== data.transfer_id
      );
      this.updateIncomingBadge();

      if (this.activeJobs[data.transfer_id]) {
        this.activeJobs[data.transfer_id].status = "CANCELLED";
        this.activeJobs[data.transfer_id].error = data.error || "Cancelled";
      }
      this.renderActiveTransfers();
      this.refreshHistory();
    });
  },

  updateIncomingBadge() {
    const badge = document.getElementById("incoming-count-badge");
    if (!badge) return;
    const count = this.pendingIncomingRequests.length;
    badge.textContent = count;
    badge.style.display = count > 0 ? "inline-block" : "none";
  },

  renderIncomingStack() {
    const stack = document.getElementById("incoming-requests-stack");
    if (!stack) return;

    // Render cards for all pending incoming requests
    this.pendingIncomingRequests.forEach((req) => {
      const existingCard = stack.querySelector(`[data-transfer-id="${req.transfer_id}"]`);
      if (!existingCard) {
        const card = this.createIncomingCardElement(req);
        stack.appendChild(card);
      }
    });

    // Remove any cards that are no longer pending (ignore cards currently showing accepted/rejected state)
    const currentIds = new Set(this.pendingIncomingRequests.map((r) => r.transfer_id));
    stack.querySelectorAll(".incoming-request-card").forEach((card) => {
      const id = card.getAttribute("data-transfer-id");
      if (
        id &&
        !currentIds.has(id) &&
        !card.classList.contains("removing") &&
        !card.classList.contains("state-accepted") &&
        !card.classList.contains("state-rejected")
      ) {
        this.removeIncomingCard(id);
      }
    });
  },

  createIncomingCardElement(req) {
    const card = document.createElement("div");
    card.className = "incoming-request-card";
    card.setAttribute("data-transfer-id", req.transfer_id);

    const senderName = req.sender?.username || "Peer";
    const senderHost = req.sender?.hostname ? `(${req.sender.hostname})` : "";
    const itemName = req.item_name || "file";
    const itemSize = formatBytes(req.total_bytes || 0);
    const isFolder = !!req.is_folder;

    const fileIconSvg = isFolder
      ? `<svg class="req-file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/></svg>`
      : `<svg class="req-file-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>`;

    card.innerHTML = `
      <div class="req-card-top">
        <div class="req-card-badge">
          <span class="req-card-pulse"></span>
          <span>Incoming Transfer</span>
        </div>
        <span class="req-card-hint">Click for details</span>
      </div>
      <div class="req-card-content">
        <div class="req-card-info">
          <div class="req-card-sender" title="${escapeHtml(senderName)} ${escapeHtml(senderHost)}">
            <svg class="req-sender-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
            </svg>
            <span class="req-sender-name">${escapeHtml(senderName)}</span>
            <span class="req-sender-host">${escapeHtml(senderHost)}</span>
          </div>
          <div class="req-card-file" title="${escapeHtml(itemName)} (${itemSize})">
            ${fileIconSvg}
            <span class="req-file-name">${escapeHtml(itemName)}</span>
            <span class="req-file-size">${itemSize}</span>
          </div>
        </div>
        <div class="req-card-actions">
          <button type="button" class="req-action-btn req-btn-accept" title="Accept transfer (One-click)" aria-label="Accept Transfer">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </button>
          <button type="button" class="req-action-btn req-btn-reject" title="Reject transfer (One-click)" aria-label="Reject Transfer">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>
    `;

    // Clicking anywhere on the card body opens the full modal interface
    card.addEventListener("click", () => {
      if (card.classList.contains("state-accepted") || card.classList.contains("state-rejected")) return;
      this.showIncomingModal(req);
    });

    // Tick button accepts transfer directly in one click
    const btnAccept = card.querySelector(".req-btn-accept");
    if (btnAccept) {
      btnAccept.addEventListener("click", (e) => {
        e.stopPropagation();
        this.acceptIncomingRequest(req.transfer_id);
      });
    }

    // Cross button rejects transfer directly in one click
    const btnReject = card.querySelector(".req-btn-reject");
    if (btnReject) {
      btnReject.addEventListener("click", (e) => {
        e.stopPropagation();
        this.rejectIncomingRequest(req.transfer_id);
      });
    }

    return card;
  },

  removeIncomingCard(transfer_id) {
    const stack = document.getElementById("incoming-requests-stack");
    if (!stack) return;
    const card = stack.querySelector(`[data-transfer-id="${transfer_id}"]`);
    if (card) {
      card.classList.add("removing");
      setTimeout(() => {
        card.remove();
      }, 220);
    }
  },

  async acceptIncomingRequest(transfer_id) {
    // Remove from pending incoming requests array and update badge count
    this.pendingIncomingRequests = this.pendingIncomingRequests.filter(
      (r) => r.transfer_id !== transfer_id
    );
    this.updateIncomingBadge();

    // Close modal if open
    const modal = document.getElementById("incoming-request-modal");
    if (modal) modal.classList.remove("active");

    // Display accepted notification directly inside the request box
    const stack = document.getElementById("incoming-requests-stack");
    const card = stack ? stack.querySelector(`[data-transfer-id="${transfer_id}"]`) : null;
    if (card) {
      card.classList.add("state-accepted");
      card.style.pointerEvents = "none";

      const hint = card.querySelector(".req-card-hint");
      if (hint) hint.style.display = "none";

      const badge = card.querySelector(".req-card-badge");
      if (badge) {
        badge.className = "req-card-badge status-accepted-text";
        badge.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span>Request Accepted</span>
        `;
      }

      const actions = card.querySelector(".req-card-actions");
      if (actions) {
        actions.innerHTML = `
          <div class="req-inline-status status-accepted-pill">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            <span>Accepted</span>
          </div>
        `;
      }

      // Keep notification visible inside the request box for 1.8s, then smoothly slide out
      setTimeout(() => {
        this.removeIncomingCard(transfer_id);
      }, 1800);
    }

    try {
      await API.acceptTransfer(transfer_id);
      if (typeof window.switchTab === "function") {
        window.switchTab("tab-transfers");
      }
    } catch (err) {
      console.error("Accept transfer error:", err);
    }
  },

  async rejectIncomingRequest(transfer_id) {
    // Remove from pending incoming requests array and update badge count
    this.pendingIncomingRequests = this.pendingIncomingRequests.filter(
      (r) => r.transfer_id !== transfer_id
    );
    this.updateIncomingBadge();

    // Close modal if open
    const modal = document.getElementById("incoming-request-modal");
    if (modal) modal.classList.remove("active");

    // Display rejected notification directly inside the request box
    const stack = document.getElementById("incoming-requests-stack");
    const card = stack ? stack.querySelector(`[data-transfer-id="${transfer_id}"]`) : null;
    if (card) {
      card.classList.add("state-rejected");
      card.style.pointerEvents = "none";

      const hint = card.querySelector(".req-card-hint");
      if (hint) hint.style.display = "none";

      const badge = card.querySelector(".req-card-badge");
      if (badge) {
        badge.className = "req-card-badge status-rejected-text";
        badge.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
          <span>Request Rejected</span>
        `;
      }

      const actions = card.querySelector(".req-card-actions");
      if (actions) {
        actions.innerHTML = `
          <div class="req-inline-status status-rejected-pill">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
            <span>Rejected</span>
          </div>
        `;
      }

      // Keep notification visible inside the request box for 1.8s, then smoothly slide out
      setTimeout(() => {
        this.removeIncomingCard(transfer_id);
      }, 1800);
    }

    try {
      await API.rejectTransfer(transfer_id);
    } catch (err) {
      console.error("Reject transfer error:", err);
    }
  },

  showIncomingModal(req) {
    const modal = document.getElementById("incoming-request-modal");
    if (!modal) return;

    document.getElementById("modal-sender-name").textContent =
      `${req.sender?.username || "Peer"} — ${req.sender?.hostname || "Local Device"}`;
    document.getElementById("modal-file-name").textContent = req.item_name || "file";
    document.getElementById("modal-file-size").textContent = formatBytes(req.total_bytes || 0);

    const resumeTag = document.getElementById("modal-resume-tag");
    if (resumeTag) {
      resumeTag.style.display = req.is_resumed ? "inline-block" : "none";
      if (req.is_resumed) {
        resumeTag.textContent = `Resume from ${formatBytes(req.resume_offset || 0)}`;
      }
    }

    const btnAccept = document.getElementById("modal-btn-accept");
    const btnReject = document.getElementById("modal-btn-reject");
    const btnClose = document.getElementById("modal-btn-close");

    btnAccept.onclick = () => {
      this.acceptIncomingRequest(req.transfer_id);
    };

    btnReject.onclick = () => {
      this.rejectIncomingRequest(req.transfer_id);
    };

    if (btnClose) {
      btnClose.onclick = () => {
        modal.classList.remove("active");
      };
    }

    modal.onclick = (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
      }
    };

    modal.classList.add("active");
  },

  renderActiveTransfers() {
    const container = document.getElementById("active-transfers-container");
    if (!container) return;

    const jobs = Object.values(this.activeJobs);
    const inProgressJobs = jobs.filter((j) => j.status === "IN_PROGRESS");
    const elStatusTransfers = document.getElementById("status-transfers");
    if (elStatusTransfers) {
      elStatusTransfers.textContent = `${inProgressJobs.length} active transfer${inProgressJobs.length === 1 ? "" : "s"}`;
    }

    if (jobs.length === 0) {
      container.innerHTML = `
        <div class="modern-empty-state">
          <div class="empty-state-icon-glow">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="m3 16 4 4 4-4"/><path d="M7 20V4"/><path d="m21 8-4-4-4 4"/><path d="M17 4v16"/>
            </svg>
          </div>
          <h3 class="empty-state-title">No Active Data Transfers</h3>
          <p class="empty-state-desc">Transfers initiated to or from other local LAN nodes will stream in real time here with chunk-level metrics.</p>
          <div class="empty-state-actions">
            <button class="btn btn-secondary btn-sm" onclick="window.switchTab('tab-home')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
              <span>Stage New Transfer</span>
            </button>
          </div>
        </div>
      `;
      return;
    }

    container.innerHTML = "";
    jobs.forEach((job) => {
      const card = document.createElement("div");
      card.className = "transfer-card";
      card.dataset.transferId = job.id;

      const isIncoming = job.direction === "INCOMING";
      const dirIcon = isIncoming
        ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><line x1="17" x2="7" y1="7" y2="17"/><polyline points="17 17 7 17 7 7"/></svg>`
        : `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><line x1="7" x2="17" y1="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>`;
      const dirText = isIncoming ? "Receiving from" : "Sending to";
      const peerText = job.peer_username || "Peer";

      let statusBadgeClass = "badge-neutral";
      if (job.status === "IN_PROGRESS") statusBadgeClass = "badge-info";
      if (job.status === "PAUSED") statusBadgeClass = "badge-warning";
      if (job.status === "COMPLETED") statusBadgeClass = "badge-success";
      if (job.status === "FAILED") statusBadgeClass = "badge-danger";
      if (job.status === "REJECTED") statusBadgeClass = "badge-warning";
      if (job.status === "CANCELLED") statusBadgeClass = "badge-neutral";

      let progressClass = "";
      if (job.status === "COMPLETED") progressClass = "progress-success";
      if (job.status === "FAILED" || job.status === "REJECTED") progressClass = "progress-danger";

      const currentPrio = (job.priority || "MEDIUM").toUpperCase();
      const isActiveJob = job.status === "IN_PROGRESS" || job.status === "PAUSED";

      let footerHtml = "";
      if (isActiveJob) {
        const pauseResumeBtn = job.status === "PAUSED"
          ? `<button type="button" class="btn btn-secondary btn-xs btn-transfer-resume" title="Resume transfer">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
               <span>Resume</span>
             </button>`
          : `<button type="button" class="btn btn-secondary btn-xs btn-transfer-pause" title="Pause transfer">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
               <span>Pause</span>
             </button>`;

        // Requirement: Priority can only be set by the sender
        const priorityControlHtml = job.direction === "OUTGOING"
          ? `<div class="fdm-priority-control">
              <span class="fdm-prio-title">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                Priority
              </span>
              <div class="fdm-prio-group" role="group" aria-label="Transfer Priority">
                <button type="button" class="fdm-prio-btn prio-low ${currentPrio === 'LOW' ? 'active' : ''}" data-prio="LOW" title="Low: Background speed, leaves network free for other work">
                  <span class="fdm-dot"></span> Low
                </button>
                <button type="button" class="fdm-prio-btn prio-med ${currentPrio === 'MEDIUM' ? 'active' : ''}" data-prio="MEDIUM" title="Normal: Standard balanced speed">
                  <span class="fdm-dot"></span> Normal
                </button>
                <button type="button" class="fdm-prio-btn prio-high ${currentPrio === 'HIGH' ? 'active' : ''}" data-prio="HIGH" title="High: Maximum uncapped transfer throughput">
                  <span class="fdm-dot"></span> High
                </button>
              </div>
            </div>`
          : `<div class="fdm-priority-control receiver-view">
              <span class="fdm-prio-readonly-badge" title="Transfer priority is set by sender">
                <span class="fdm-dot"></span> Priority: <strong class="font-mono">${currentPrio === 'MEDIUM' ? 'Normal' : currentPrio}</strong> <span class="text-muted" style="font-size:10px;">(Sender-set)</span>
              </span>
            </div>`;

        footerHtml = `
          <div class="transfer-card-footer">
            ${priorityControlHtml}
            <div class="transfer-card-actions">
              ${pauseResumeBtn}
              <button type="button" class="btn btn-danger-outline btn-xs btn-transfer-cancel" title="Cancel transfer">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                <span>Cancel</span>
              </button>
            </div>
          </div>
        `;
      } else {
        footerHtml = `
          <div class="transfer-card-footer">
            <div class="transfer-footer-left">
              <span class="text-xs text-muted">Priority: <strong class="text-primary font-mono">${currentPrio === 'MEDIUM' ? 'Normal' : currentPrio}</strong></span>
            </div>
            <div class="transfer-card-actions">
              <button type="button" class="btn btn-secondary btn-xs btn-transfer-dismiss" title="Dismiss from list">
                <span>Dismiss</span>
              </button>
            </div>
          </div>
        `;
      }

      card.innerHTML = `
        <div class="transfer-header">
          <div class="transfer-title">
            <span class="transfer-dir-icon">${dirIcon}</span>
            <span class="transfer-item-name">${escapeHtml(job.name || "Transfer")}</span>
            <span class="transfer-peer-caption">(${dirText} ${escapeHtml(peerText)})</span>
          </div>
          <div>
            <span class="badge ${statusBadgeClass}">
              <span class="badge-dot"></span>
              ${job.status}
            </span>
          </div>
        </div>

        <div class="transfer-stats">
          <div class="transfer-stats-left">
            <span class="tabular-nums">${formatBytes(job.transferred_bytes || 0)} / ${formatBytes(job.total_bytes || 0)}</span>
            <span class="transfer-speed tabular-nums">${job.speed_mbps || 0} MB/s</span>
            ${job.chunk_size_kb ? `<span class="transfer-chunk-size tabular-nums">(Chunk: ${job.chunk_size_kb}KB)</span>` : ""}
          </div>
          <div class="transfer-stats-right">
            <span class="transfer-percent tabular-nums">${job.percent || 0}%</span>
            ${job.eta_seconds > 0 ? `<span class="transfer-eta tabular-nums">(${job.eta_seconds}s remaining)</span>` : ""}
          </div>
        </div>

        <div class="progress-bar">
          <div class="progress-fill ${progressClass}" style="width: ${job.percent || 0}%;"></div>
        </div>

        ${footerHtml}
      `;

      // Wire interactive events for priority and actions
      if (isActiveJob) {
        card.querySelectorAll(".fdm-prio-btn").forEach((btn) => {
          btn.addEventListener("click", async (e) => {
            e.stopPropagation();
            const newPrio = btn.getAttribute("data-prio");
            if (!newPrio || newPrio === job.priority) return;

            // Optimistic active toggle for instantaneous UI feedback
            job.priority = newPrio;
            card.querySelectorAll(".fdm-prio-btn").forEach((b) => {
              b.classList.toggle("active", b.getAttribute("data-prio") === newPrio);
            });

            try {
              const res = await API.updateTransferPriority(job.id, newPrio);
            } catch (err) {
              console.error("Failed to update priority:", err);
            }
          });
        });

        const btnPause = card.querySelector(".btn-transfer-pause");
        if (btnPause) {
          btnPause.addEventListener("click", async (e) => {
            e.stopPropagation();
            btnPause.disabled = true;
            try {
              await API.pauseTransfer(job.id);
              job.status = "PAUSED";
              this.renderActiveTransfers();
            } catch (err) {
              console.error("Pause failed:", err);
            }
          });
        }

        const btnResume = card.querySelector(".btn-transfer-resume");
        if (btnResume) {
          btnResume.addEventListener("click", async (e) => {
            e.stopPropagation();
            btnResume.disabled = true;
            try {
              await API.resumeTransfer(job.id);
              job.status = "IN_PROGRESS";
              this.renderActiveTransfers();
            } catch (err) {
              console.error("Resume failed:", err);
            }
          });
        }

        const btnCancel = card.querySelector(".btn-transfer-cancel");
        if (btnCancel) {
          btnCancel.addEventListener("click", async (e) => {
            e.stopPropagation();
            btnCancel.disabled = true;
            try {
              await API.cancelTransfer(job.id);
              job.status = "CANCELLED";
              this.renderActiveTransfers();
            } catch (err) {
              console.error("Cancel failed:", err);
            }
          });
        }
      } else {
        const btnDismiss = card.querySelector(".btn-transfer-dismiss");
        if (btnDismiss) {
          btnDismiss.addEventListener("click", (e) => {
            e.stopPropagation();
            delete this.activeJobs[job.id];
            this.renderActiveTransfers();
          });
        }
      }

      container.appendChild(card);
    });
  },

  updateSortHeaderIndicators() {
    const indicators = {
      name: document.getElementById("sort-ind-name"),
      date: document.getElementById("sort-ind-date"),
      duration: document.getElementById("sort-ind-duration"),
      speed: document.getElementById("sort-ind-speed"),
    };
    Object.keys(indicators).forEach((key) => {
      const el = indicators[key];
      if (!el) return;
      if (this.historySortBy === key) {
        el.textContent = this.historySortOrder === "asc" ? " ▲" : " ▼";
        el.style.opacity = "1";
      } else {
        el.textContent = "";
        el.style.opacity = "0.3";
      }
    });
  },

  formatDateTime(isoString) {
    if (!isoString) return '<span class="text-muted">—</span>';
    try {
      const d = new Date(isoString);
      if (isNaN(d.getTime())) return `<span class="mono">${escapeHtml(isoString)}</span>`;
      const datePart = d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
      const timePart = d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      return `
        <div class="date-time-cell" title="${escapeHtml(isoString)}">
          <span class="date-text">${datePart}</span>
          <span class="time-text mono text-muted">${timePart}</span>
        </div>
      `;
    } catch (e) {
      return `<span class="mono">${escapeHtml(isoString)}</span>`;
    }
  },

  formatDuration(sec, status) {
    if (status === "REJECTED" || status === "PENDING") {
      return '<span class="text-muted">—</span>';
    }
    const s = Number(sec);
    if (isNaN(s) || s <= 0) {
      return status === "COMPLETED" ? '<span class="tabular-nums font-mono">&lt; 0.1s</span>' : '<span class="text-muted">—</span>';
    }
    if (s < 1) {
      return `<span class="tabular-nums font-mono">${s.toFixed(2)}s</span>`;
    } else if (s < 60) {
      return `<span class="tabular-nums font-mono">${s.toFixed(1)}s</span>`;
    } else {
      const mins = Math.floor(s / 60);
      const remSec = Math.round(s % 60);
      return `<span class="tabular-nums font-mono">${mins}m ${remSec}s</span>`;
    }
  },

  formatSpeed(speedMbps, status) {
    if (status === "REJECTED" || status === "PENDING" || (status === "CANCELLED" && !speedMbps)) {
      return '<span class="text-muted">—</span>';
    }
    const spd = Number(speedMbps);
    if (!spd || isNaN(spd) || spd <= 0) {
      return '<span class="text-muted">—</span>';
    }
    return `<span class="tabular-nums font-semibold font-mono">${spd.toFixed(2)} MB/s</span>`;
  },

  async refreshHistory() {
    const searchInput = document.getElementById("search-history-input");
    const statusSelect = document.getElementById("filter-status-select");
    const dirSelect = document.getElementById("filter-direction-select");

    const q = searchInput ? searchInput.value.trim() : "";
    const status = statusSelect ? statusSelect.value : "";
    const direction = dirSelect ? dirSelect.value : "";

    try {
      const data = await API.getHistory(
        q,
        status,
        direction,
        this.historySortBy,
        this.historySortOrder
      );
      const tbody = document.getElementById("history-table-body");
      if (!tbody) return;

      if (!data.transfers || data.transfers.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="8">
              <div class="empty-state" style="padding: var(--space-6) var(--space-4);">
                <div class="empty-state-icon">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
                    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                  </svg>
                </div>
                <h3 class="empty-state-title">No transfer records found</h3>
                <p class="empty-state-desc">Transfers sent or received will appear here with sender/receiver details, timestamps, duration, and speed.</p>
              </div>
            </td>
          </tr>
        `;
        return;
      }

      tbody.innerHTML = "";
      data.transfers.forEach((tx) => {
        const tr = document.createElement("tr");

        const isIncoming = tx.direction === "INCOMING";
        const dirBadge = isIncoming
          ? `<span class="badge-incoming" title="Received from peer"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="17" x2="7" y1="7" y2="17"/><polyline points="17 17 7 17 7 7"/></svg> RECEIVED</span>`
          : `<span class="badge-outgoing" title="Sent to peer"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" x2="17" y1="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg> SENT</span>`;

        const isFolder = Boolean(tx.is_folder);
        const folderTag = isFolder
          ? `<span class="badge badge-neutral" style="margin-left: 6px; font-size: 10px; padding: 1px 5px;">Folder</span>`
          : "";
        const fileCell = `
          <div style="display: flex; align-items: center; gap: 4px;">
            <span class="font-medium truncate" style="max-width: 220px;" title="${escapeHtml(tx.file_name)}">${escapeHtml(tx.file_name)}</span>
            ${folderTag}
          </div>
        `;

        const peerName = escapeHtml(tx.peer_username || "Unknown");
        const peerHost = tx.peer_hostname ? `(${escapeHtml(tx.peer_hostname)})` : "";
        const roleBadge = isIncoming
          ? `<span class="role-badge role-from" title="Sender of file">From:</span>`
          : `<span class="role-badge role-to" title="Recipient of file">To:</span>`;

        const peerCell = `
          <div class="peer-role-container">
            ${roleBadge}
            <span class="peer-name font-medium">${peerName}</span>
            <span class="peer-host text-muted mono" style="font-size: 11px;">${peerHost}</span>
          </div>
        `;

        let statusBadge = `<span class="badge badge-neutral">${escapeHtml(tx.status)}</span>`;
        if (tx.status === "COMPLETED") {
          statusBadge = `<span class="badge badge-success"><span class="badge-dot"></span>Completed</span>`;
        } else if (tx.status === "FAILED") {
          statusBadge = `<span class="badge badge-danger" title="${escapeHtml(tx.error_message || '')}"><span class="badge-dot"></span>Failed</span>`;
        } else if (tx.status === "REJECTED") {
          statusBadge = `<span class="badge badge-warning"><span class="badge-dot"></span>Rejected</span>`;
        } else if (tx.status === "CANCELLED") {
          statusBadge = `<span class="badge badge-neutral"><span class="badge-dot"></span>Cancelled</span>`;
        } else if (tx.status === "IN_PROGRESS") {
          statusBadge = `<span class="badge badge-info"><span class="badge-dot"></span>In Progress</span>`;
        }

        tr.innerHTML = `
          <td>${dirBadge}</td>
          <td>${fileCell}</td>
          <td>${peerCell}</td>
          <td>${this.formatDateTime(tx.started_at)}</td>
          <td class="tabular-nums font-mono">${formatBytes(tx.total_bytes)}</td>
          <td>${this.formatDuration(tx.duration_seconds, tx.status)}</td>
          <td>${this.formatSpeed(tx.average_speed_mbps, tx.status)}</td>
          <td>${statusBadge}</td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      console.error("Failed to fetch history:", err);
    }
  },

  async refreshDownloadedFiles() {
    const searchInput = document.getElementById("search-files-input");
    const q = searchInput ? searchInput.value : "";

    try {
      const data = await API.getDownloadedFiles(q);
      const container = document.getElementById("downloaded-files-list");
      const dirDisplay = document.getElementById("current-download-dir-display");
      if (dirDisplay) dirDisplay.textContent = data.download_dir;

      if (!container) return;

      if (!data.files || data.files.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
                <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>
              </svg>
            </div>
            <h3 class="empty-state-title">Download directory is empty</h3>
            <p class="empty-state-desc">Files and folders received from LAN peers will be stored here.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = "";
      data.files.forEach((file) => {
        const item = document.createElement("div");
        item.className = "file-item-row";

        const modifiedDate = file.modified_at ? file.modified_at.split("T")[0] : "-";
        const relativeTarget = file.relative_path || file.name;

        item.innerHTML = `
          <div class="file-item-left">
            <div class="file-item-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
                <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>
              </svg>
            </div>
            <div class="file-item-meta">
              <div class="file-item-name">${escapeHtml(file.name)}</div>
              <div class="file-item-sub mono">${escapeHtml(file.relative_path)} &bull; Modified ${modifiedDate}</div>
            </div>
          </div>
          <div class="file-item-right">
            <span class="badge badge-neutral tabular-nums">${formatBytes(file.size_bytes)}</span>
          </div>
        `;

        container.appendChild(item);
      });
    } catch (err) {
      console.error("Failed to fetch downloaded files:", err);
    }
  },
};
