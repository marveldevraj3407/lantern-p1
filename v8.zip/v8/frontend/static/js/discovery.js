/**
 * Device discovery and recipient selection logic.
 */

const DiscoveryModule = {
  selectedPeerIds: new Set(),
  currentSourceItem: null, // { path, name, is_folder, size }

  init() {
    this.bindEvents();
    this.refreshPeers();

    // Listen for live peer updates from UDP discovery
    API.on("PEERS_UPDATED", (peers) => {
      this.renderPeers(peers);
    });
  },

  bindEvents() {
    const btnSelectAll = document.getElementById("btn-select-all");
    const btnClearAll = document.getElementById("btn-clear-all");
    const btnSelectFile = document.getElementById("btn-select-file");
    const btnSelectFolder = document.getElementById("btn-select-folder");
    const btnSend = document.getElementById("btn-send-transfer");
    const btnRefresh = document.getElementById("btn-refresh-discovery");
    const interactiveDropzone = document.getElementById("interactive-dropzone");

    if (btnSelectAll) {
      btnSelectAll.addEventListener("click", () => this.selectAllPeers());
    }
    if (btnClearAll) {
      btnClearAll.addEventListener("click", () => this.clearAllPeers());
    }
    if (btnSelectFile) {
      btnSelectFile.addEventListener("click", (e) => {
        e.stopPropagation();
        this.selectFile();
      });
    }
    if (btnSelectFolder) {
      btnSelectFolder.addEventListener("click", (e) => {
        e.stopPropagation();
        this.selectFolder();
      });
    }
    if (btnSend) {
      btnSend.addEventListener("click", () => this.startSendTransfer());
    }

    // Drag-and-drop on interactive dropzone
    if (interactiveDropzone) {
      interactiveDropzone.addEventListener("click", (e) => {
        // If user didn't click one of the specific choice buttons, trigger file select
        if (!e.target.closest("#btn-select-file") && !e.target.closest("#btn-select-folder")) {
          this.selectFile();
        }
      });

      interactiveDropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        interactiveDropzone.classList.add("drag-over");
      });
      interactiveDropzone.addEventListener("dragleave", () => {
        interactiveDropzone.classList.remove("drag-over");
      });
      interactiveDropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        interactiveDropzone.classList.remove("drag-over");
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          const f = e.dataTransfer.files[0];
          if (f.path) {
            this.applyManualPathString(f.path);
          } else {
            this.currentSourceItem = {
              path: f.name,
              name: f.name,
              size: f.size,
              is_folder: false,
            };
            this.renderSelectedFile();
          }
        }
      });
    }

    // Drag-and-drop support on the selected file box
    const dropBox = document.getElementById("selected-file-display");
    if (dropBox) {
      dropBox.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropBox.classList.add("drag-over");
      });
      dropBox.addEventListener("dragleave", () => {
        dropBox.classList.remove("drag-over");
      });
      dropBox.addEventListener("drop", (e) => {
        e.preventDefault();
        dropBox.classList.remove("drag-over");
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          const f = e.dataTransfer.files[0];
          if (f.path) {
            this.applyManualPathString(f.path);
          } else {
            this.currentSourceItem = {
              path: f.name,
              name: f.name,
              size: f.size,
              is_folder: false,
            };
            this.renderSelectedFile();
          }
        }
      });
    }

    if (btnRefresh) {
      btnRefresh.addEventListener("click", async () => {
        btnRefresh.disabled = true;
        const origContent = btnRefresh.innerHTML;
        btnRefresh.innerHTML = `<span>Scanning...</span>`;
        try {
          await API.refreshPeersBroadcast();
          setTimeout(() => this.refreshPeers(), 500);
        } catch (err) {
          console.error("Refresh failed:", err);
        } finally {
          setTimeout(() => {
            btnRefresh.disabled = false;
            btnRefresh.innerHTML = origContent;
          }, 800);
        }
      });
    }
  },

  async refreshPeers() {
    try {
      const data = await API.getPeers();
      this.renderPeers(data.peers || []);
    } catch (err) {
      console.error("Failed to fetch peers:", err);
    }
  },

  renderPeers(peers) {
    const container = document.getElementById("available-devices-list");
    const countBadge = document.getElementById("online-devices-count");
    if (!container) return;

    // Strictly filter for online peers only: disconnected peers disappear completely from list
    const onlinePeers = (peers || []).filter((p) => p && p.is_online !== false);

    // Prune stale selected peer IDs that are no longer online
    const onlineIds = new Set(onlinePeers.map((p) => p.device_id));
    for (const devId of Array.from(this.selectedPeerIds)) {
      if (!onlineIds.has(devId)) {
        this.selectedPeerIds.delete(devId);
      }
    }

    if (countBadge) {
      countBadge.innerHTML = `<span class="badge-dot"></span>${onlinePeers.length} online`;
    }
    const elStatusPeers = document.getElementById("status-peers");
    if (elStatusPeers) {
      elStatusPeers.textContent = `${onlinePeers.length} peer${onlinePeers.length === 1 ? "" : "s"} online`;
    }

    if (onlinePeers.length === 0) {
      container.innerHTML = `
        <div class="simple-empty-devices">
          <div class="simple-device-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
              <rect width="18" height="12" x="3" y="4" rx="2"></rect><line x1="2" x2="22" y1="20" y2="20"></line>
            </svg>
          </div>
          <h3 class="simple-empty-title">No devices found</h3>
          <p class="simple-empty-desc">Make sure other computers are connected to the same Wi-Fi network and have L.A.N.T.E.R.N. open.</p>
          <button class="btn btn-secondary btn-sm" onclick="document.getElementById('btn-refresh-discovery').click()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></svg>
            <span>Scan</span>
          </button>
        </div>
      `;
      this.updateSendButtonState();
      return;
    }

    container.innerHTML = "";
    onlinePeers.forEach((peer) => {
      const isSelected = this.selectedPeerIds.has(peer.device_id);
      const card = document.createElement("div");
      card.className = `peer-card ${isSelected ? "selected" : ""}`;
      card.dataset.deviceId = peer.device_id;

      card.innerHTML = `
        <div class="peer-info">
          <input type="checkbox" class="custom-checkbox peer-checkbox" ${isSelected ? "checked" : ""} aria-label="Select ${escapeHtml(peer.username)}">
          <div class="peer-avatar" title="${escapeHtml(peer.username)}">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75">
              <rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/>
            </svg>
          </div>
          <div class="peer-details">
            <div class="peer-name">
              <span class="peer-username-text">${escapeHtml(peer.username)}</span>
              <span class="peer-hostname-pill mono">${escapeHtml(peer.hostname)}</span>
            </div>
            <div class="peer-sub">
              <span class="ip-tag tabular-nums">${escapeHtml(peer.ip)}</span>
            </div>
          </div>
        </div>
        <div class="peer-status-col">
          <span class="badge badge-success"><span class="badge-dot"></span>Online</span>
        </div>
      `;

      const chk = card.querySelector(".peer-checkbox");
      const toggleSelection = (forceVal) => {
        const nextState = forceVal !== undefined ? forceVal : !this.selectedPeerIds.has(peer.device_id);
        if (chk) chk.checked = nextState;
        if (nextState) {
          this.selectedPeerIds.add(peer.device_id);
          card.classList.add("selected");
        } else {
          this.selectedPeerIds.delete(peer.device_id);
          card.classList.remove("selected");
        }
        this.updateSendButtonState();
      };

      if (chk) {
        chk.addEventListener("change", (e) => {
          e.stopPropagation();
          toggleSelection(chk.checked);
        });
      }

      // Single-click on card immediately toggles selection
      card.addEventListener("click", (e) => {
        if (e.target === chk) return;
        toggleSelection();
      });

      container.appendChild(card);
    });

    this.updateSendButtonState();
  },

  selectAllPeers() {
    const cards = document.querySelectorAll(".peer-card");
    cards.forEach((card) => {
      const chk = card.querySelector(".peer-checkbox");
      if (chk && !chk.disabled) {
        chk.checked = true;
        this.selectedPeerIds.add(card.dataset.deviceId);
        card.classList.add("selected");
      }
    });
    this.updateSendButtonState();
  },

  clearAllPeers() {
    this.selectedPeerIds.clear();
    const cards = document.querySelectorAll(".peer-card");
    cards.forEach((card) => {
      const chk = card.querySelector(".peer-checkbox");
      if (chk) chk.checked = false;
      card.classList.remove("selected");
    });
    this.updateSendButtonState();
  },

  async selectFile() {
    const btn = document.getElementById("btn-select-file");
    if (btn) btn.classList.add("loading");
    try {
      const res = await API.selectFileNative();
      if (res && res.selected) {
        this.currentSourceItem = res;
        this.renderSelectedFile();
      }
    } catch (err) {
      console.error("Error opening file dialog:", err);
    } finally {
      if (btn) btn.classList.remove("loading");
    }
  },

  async selectFolder() {
    const btn = document.getElementById("btn-select-folder");
    if (btn) btn.classList.add("loading");
    try {
      const res = await API.selectFolderNative();
      if (res && res.selected) {
        this.currentSourceItem = res;
        this.renderSelectedFile();
      }
    } catch (err) {
      console.error("Error opening folder dialog:", err);
    } finally {
      if (btn) btn.classList.remove("loading");
    }
  },

  async applyManualPathString(rawPath) {
    try {
      const res = await API.selectPathDirect(rawPath);
      if (res && res.selected) {
        this.currentSourceItem = res;
        this.renderSelectedFile();
      }
    } catch (err) {
      console.error("Failed to select path:", err);
    }
  },

  clearSelectedFile() {
    this.currentSourceItem = null;
    this.renderSelectedFile();
  },

  renderSelectedFile() {
    const box = document.getElementById("selected-file-display");
    const btnFile = document.getElementById("btn-select-file");
    const btnFolder = document.getElementById("btn-select-folder");

    // Update active highlight on selection tiles
    if (btnFile && btnFolder) {
      btnFile.classList.remove("active-selection");
      btnFolder.classList.remove("active-selection");
      if (this.currentSourceItem) {
        if (this.currentSourceItem.is_folder) {
          btnFolder.classList.add("active-selection");
        } else {
          btnFile.classList.add("active-selection");
        }
      }
    }

    if (!box) return;

    if (!this.currentSourceItem) {
      box.style.display = "none";
      box.innerHTML = "";
    } else {
      box.style.display = "block";
      box.className = "selected-file-box active";
      const isFolder = this.currentSourceItem.is_folder;
      const sizeStr = isFolder ? "Folder" : formatBytes(this.currentSourceItem.size || 0);

      const iconSvg = isFolder
        ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>`
        : `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>`;

      box.innerHTML = `
        <div class="selected-item-card">
          <div class="selected-item-left">
            <div class="selected-type-badge ${isFolder ? "folder" : "file"}">
              ${iconSvg}
            </div>
            <div class="selected-item-meta">
              <div class="selected-item-name-row">
                <span class="selected-item-name">${escapeHtml(this.currentSourceItem.name)}</span>
                <span class="badge badge-neutral tabular-nums">${sizeStr}</span>
              </div>
              <div class="selected-item-path mono" title="${escapeHtml(this.currentSourceItem.path)}">
                ${escapeHtml(this.currentSourceItem.path)}
              </div>
            </div>
          </div>
          <button type="button" class="btn btn-ghost btn-sm" title="Remove selected file" onclick="DiscoveryModule.clearSelectedFile()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <span>Remove</span>
          </button>
        </div>
      `;
    }
    this.updateSendButtonState();
  },

  updateSendButtonState() {
    const btn = document.getElementById("btn-send-transfer");
    const btnText = document.getElementById("btn-send-text");
    if (!btn) return;
    const hasRecipients = this.selectedPeerIds.size > 0;
    const hasItem = !!this.currentSourceItem;
    btn.disabled = !(hasRecipients && hasItem);

    const count = this.selectedPeerIds.size;
    if (btnText) {
      if (hasRecipients) {
        btnText.textContent = `Send to ${count} device${count > 1 ? "s" : ""}`;
      } else {
        btnText.textContent = "Send";
      }
    }
  },

  async startSendTransfer() {
    if (!this.currentSourceItem || this.selectedPeerIds.size === 0) return;

    const payload = {
      source_path: this.currentSourceItem.path,
      recipients: Array.from(this.selectedPeerIds),
      priority: "MEDIUM",
      is_adaptive: true,
    };

    const btn = document.getElementById("btn-send-transfer");
    if (btn) btn.disabled = true;

    try {
      const res = await API.sendTransfer(payload);
      if (res.success) {
        // Clear selection after sending
        this.clearSelectedFile();
        // Switch to Active Transfers view
        window.switchTab("tab-transfers");
      } else {
        console.error("Transfer initiation failed:", res.message);
      }
    } catch (err) {
      console.error("Transfer error:", err);
    } finally {
      if (btn) btn.disabled = false;
    }
  },
};

function formatBytes(bytes, decimals = 2) {
  if (!+bytes) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
