# UI Design System: Quiet Enterprise Utility

## Principles
1. **Calm & Predictable:** Software built for work, not a showcase. Flat surfaces, 1px borders, subtle surface steps. Zero gradients, zero neon glows, zero glassmorphism, zero ambient backdrop-filters.
2. **Dense & Utilitarian:** Strict 4px spacing grid (4, 8, 12, 16, 20, 24, 32, 40, 48px). Standard 32px height for primary controls, 28px for compact toolbar controls.
3. **Restrained Corner Radii:** Strict scale: 2px for indicators, 4px for buttons, inputs, selects, and badges; 6px for cards, panels, and modal dialogs. Nothing larger than 6px anywhere.
4. **Accessible Typography:** Local native System UI stack (`Segoe UI Variable Text`, `Segoe UI`, `system-ui`, `-apple-system`, `sans-serif`) ensuring 0ms layout shift and zero network dependencies in air-gapped LAN environments. Tabular numerals (`tabular-nums`) enforced on all metrics, speeds, file sizes, IP addresses, and timestamps.
5. **Universal Light & Dark Modes:** Neutral charcoal dark mode (`#141416` / `#1B1B1F` / `#222226`) with zero purple/navy tint. Standard Microsoft Fluent Blue accent (`#0F6CBD` light / `#479EF5` dark) with high contrast ratios exceeding WCAG AA/AAA.
6. **Consistent Iconography:** Single icon library (Lucide) rendered as crisp vector SVGs with 1.75px stroke width. No emoji anywhere. No decorative colored squares.

---

## Token Reference

### Surfaces & Backgrounds
| Token | Light Theme | Dark Theme | Purpose |
|---|---|---|---|
| `--surface-canvas` | `#F8F9FA` | `#141416` | Main window background |
| `--surface-panel` | `#FFFFFF` | `#1B1B1F` | Left navigation rail, card panels, tables |
| `--surface-card` | `#FFFFFF` | `#222226` | Elevated cards, list items |
| `--surface-subtle` | `#F1F3F5` | `#29292E` | Table headers, inset boxes, code blocks |
| `--surface-hover` | `#E9ECEF` | `#323238` | Interactive hover states |
| `--surface-active` | `#DEE2E6` | `#3C3C44` | Pressed states |
| `--surface-selected` | `#EBF3FC` | `#182B40` | Selected list items & active rail items |

### Borders
| Token | Light Theme | Dark Theme | Purpose |
|---|---|---|---|
| `--border-subtle` | `#E2E8F0` | `#2A2A30` | Dividers, subtle section boundaries |
| `--border-default` | `#CBD5E1` | `#383840` | Input borders, card borders |
| `--border-strong` | `#94A3B8` | `#52525C` | Active borders, hover outlines |
| `--border-focus` | `#0F6CBD` | `#479EF5` | 2px focus-visible outline |

### Typography & Neutrals
| Token | Light Theme | Dark Theme | Purpose |
|---|---|---|---|
| `--text-primary` | `#0F172A` | `#F3F3F5` | High-emphasis headings, primary labels |
| `--text-secondary` | `#475569` | `#C7C7CF` | Form labels, descriptions, secondary copy |
| `--text-muted` | `#64748B` | `#8E8E9A` | Helper hints, timestamps, metadata |
| `--text-disabled` | `#94A3B8` | `#585864` | Inactive controls, placeholder text |
| `--text-on-accent` | `#FFFFFF` | `#0A101D` | Text rendered on top of solid accent buttons |

### Accent: Enterprise Slate Blue
| Token | Light Theme | Dark Theme |
|---|---|---|
| `--accent-primary` | `#0F6CBD` | `#479EF5` |
| `--accent-hover` | `#115EA3` | `#62ABF7` |
| `--accent-pressed` | `#0C3B5E` | `#2886E0` |
| `--accent-subtle` | `#EBF3FC` | `#172A3E` |

### Semantic Status
| Status | Light Foreground | Light Background | Dark Foreground | Dark Background |
|---|---|---|---|---|
| **Success** | `#0E703C` | `#F1FAF3` | `#57B97D` | `#12281B` |
| **Warning** | `#B25900` | `#FFFBF2` | `#F19D38` | `#2D1D09` |
| **Danger** | `#C42B1C` | `#FDF3F2` | `#F1707A` | `#2B1417` |
| **Info** | `#0F6CBD` | `#EBF3FC` | `#479EF5` | `#172A3E` |

---

## Component Usage & Guidelines

### Buttons
- **Primary (`.btn-primary`):** Reserved for the one key action per view (e.g. "Send", "Accept & Download", "Save Settings"). Height 32px.
- **Secondary (`.btn-secondary`):** Standard default for toolbars, dialog dismissals, and secondary actions. Height 32px.
- **Ghost (`.btn-ghost`):** Low-prominence actions, icon-only utility triggers.
- **Destructive (`.btn-destructive`):** Dangerous actions (e.g. "Reject", "Cancel transfer", "Clear selection").
- **Disabled State:** Must appear plain grey (`--surface-hover` and `--text-disabled`), never a faded gradient.

### Form Inputs
- Standard height: 32px.
- Focus outline: 2px solid `var(--border-focus)` with 1px offset.
- Always provide `<label class="form-label">` in sentence case above the field and `<span class="form-hint">` below.

### Status Badges
- Small, rectangular (22px height, 4px radius), low-saturation background.
- **Rule:** Never use color alone. Always pair with a distinct SVG icon and text label (e.g. `✓ Verified`, `⚠ Queued`, `✗ Failed`).

### Data Tables
- Sticky header (`thead th`) with sentence-case column titles.
- Row height: 36px–38px.
- All numbers, byte sizes, speeds, and timestamps MUST use `.tabular-nums`.

---

## Shell Architecture

```
+--------------------------------------------------------------------------------+
| Top App Bar (44px, --surface-panel, 1px border-bottom)                         |
| Brand Icon + Title | Machine Name • IP | Avatar + Username | Theme Switcher    |
+-------------------+------------------------------------------------------------+
| Left Rail (220px) | Content Area (flex: 1, max-width: 1440px, padding: 24px)   |
| Collapsible: 48px |                                                            |
|                   | .page-header (Title + 1-line Description)                   |
| [ ] Devices & Send|                                                            |
| [ ] Transfers     | [ Tab Pane Content: Dashboard / Table / Cards / Settings ] |
| [ ] History       |                                                            |
| [ ] Files         |                                                            |
| [ ] Research      |                                                            |
| ----------------- |                                                            |
| [ ] Settings      |                                                            |
| [ ] Collapse rail |                                                            |
+-------------------+------------------------------------------------------------+
| Bottom Status Bar (28px, --surface-panel, 1px border-top, tabular numerals)    |
| LAN IP • Peers Online • Active Transfers                       v2.0 • P2P       |
+--------------------------------------------------------------------------------+
```

---

## Accessibility & Performance Standards

1. **Contrast Ratios (WCAG 2.1 AA / AAA):**
   - Light Mode: Primary text `#0F172A` on `#F8F9FA` achieves **15.2:1** (AAA).
   - Dark Mode: Primary text `#F3F3F5` on `#141416` achieves **16.1:1** (AAA).
   - Accent button text `#FFFFFF` on `#0F6CBD` achieves **4.9:1** (AA).
2. **Keyboard Navigation:**
   - Full keyboard operability via standard `Tab` and `Shift+Tab`.
   - Sharp, accessible focus ring on all interactive elements: `outline: 2px solid var(--border-focus); outline-offset: 1px;`.
3. **Screen Readers & ARIA:**
   - Decorative SVGs annotated with `aria-hidden="true"`.
   - Rail collapse toggle provided with `aria-label="Toggle navigation width"`.
   - Theme toggle provided with `aria-label="Toggle theme"`.
   - Checkboxes annotated with descriptive `aria-label`.
4. **Motion & Reduced Motion:**
   - Transitions strictly functional (120ms – 160ms ease).
   - `@media (prefers-reduced-motion: reduce)` disables all animations and transitions across all elements.
5. **Air-Gapped LAN Resilience:**
   - Zero external web fonts (uses native system font stack: `Segoe UI Variable Text`, `Segoe UI`, `system-ui`, `-apple-system`).
   - Zero external CDNs or remote CSS/JS dependencies.
   - Zero layout shift (0ms CLS).

---

## Do's and Don'ts

| Do | Don't |
|---|---|
| Use sentence case for all headings and buttons | Never use ALL-CAPS (`AVAILABLE DEVICES`) |
| Use 1px neutral borders to separate surfaces | Never use `backdrop-filter: blur()` or glow drop-shadows |
| Use Lucide vector icons with 1.75px stroke | Never use unicode emoji as UI icons |
| Use tabular numerals for metrics and numbers | Never allow number widths to fluctuate dynamically |
| Use flat solid buttons and 4px progress bars | Never use multi-stop linear gradients |
| Provide informative, static empty states | Never use looping radar animations or empty blank cards |
| Support both Light and Dark themes natively | Never hardcode theme colors or purple/navy dark tints |
