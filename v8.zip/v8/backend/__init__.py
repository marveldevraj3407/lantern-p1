"""L.A.N.T.E.R.N. (Local Area Network Transfer Engine for Rapid Networking) - Backend Package."""
__version__ = "2.0.0"
