"""Flask application entry point and REST/SSE API router."""

from __future__ import annotations

import logging
from pathlib import Path
import sys
import time
from typing import Optional
import uuid

from flask import Flask, Response, jsonify, render_template, request

from backend.config import AppConfig
from backend.database import Database
from backend.networking.discovery import DiscoveryService
from backend.networking.tcp_server import TCPServer
from backend.services.device_service import DeviceService
from backend.services.notification_service import NotificationBus
from backend.services.search_service import SearchService
from backend.services.user_service import UserService
from backend.transfer.manager import TransferManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("App")


def create_app(custom_app_data_dir: Optional[Path] = None) -> Flask:
    """Application factory initializing all system services and routes."""
    # Determine base project directories
    base_dir = Path(__file__).resolve().parent.parent
    frontend_dir = base_dir / "frontend"

    app = Flask(
        __name__,
        template_folder=str(frontend_dir / "templates"),
        static_folder=str(frontend_dir / "static"),
    )
    app.config["TEMPLATES_AUTO_RELOAD"] = True
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
    app.jinja_env.auto_reload = True
    app.jinja_env.cache = None

    @app.after_request
    def add_no_cache_headers(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response

    # Core system singletons
    config = AppConfig(custom_app_data_dir=custom_app_data_dir)
    database = Database(config.db_path)
    notifier = NotificationBus()

    discovery = DiscoveryService(
        config=config,
        on_peers_updated=lambda peers: notifier.publish("PEERS_UPDATED", [p.to_dict() for p in peers]),
    )
    tcp_server = TCPServer(
        config=config,
        database=database,
        notifier=notifier,
        discovery=discovery,
    )
    transfer_mgr = TransferManager(
        config=config,
        database=database,
        notifier=notifier,
        discovery=discovery,
        tcp_server=tcp_server,
    )

    user_service = UserService(config, discovery)
    device_service = DeviceService(config, discovery)
    search_service = SearchService(config, database)

    # Start network daemons
    discovery.start()
    tcp_server.start()

    # Store handles in app context
    app.config_obj = config
    app.database_obj = database
    app.notifier_obj = notifier
    app.discovery_obj = discovery
    app.tcp_server_obj = tcp_server
    app.transfer_mgr_obj = transfer_mgr

    # --- HTML Route ---
    @app.route("/")
    def index():
        return render_template("index.html")

    # --- Real-Time SSE Stream ---
    @app.route("/api/events")
    def event_stream():
        client_queue = notifier.subscribe()
        return Response(
            notifier.sse_stream(client_queue),
            mimetype="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    # --- Device & User Profile APIs ---
    @app.route("/api/status", methods=["GET"])
    def get_status():
        return jsonify({
            "config": config.to_dict(),
            "device": device_service.get_device_info(),
        })

    @app.route("/api/user/setup", methods=["POST"])
    def setup_user():
        data = request.get_json() or {}
        candidate = data.get("username", "")
        # On first launch setup, verify LAN uniqueness (skip if running automated tests)
        skip_lan = app.config.get("TESTING", False)
        ok, msg = user_service.set_username(candidate, skip_lan_check=skip_lan)
        if not ok:
            return jsonify({"success": False, "message": msg}), 400
        return jsonify({"success": True, "message": msg, "user": user_service.get_user_profile()})

    @app.route("/api/user/update", methods=["POST"])
    def update_user():
        data = request.get_json() or {}
        candidate = data.get("username", "")
        skip_lan = app.config.get("TESTING", False)
        ok, msg = user_service.set_username(candidate, skip_lan_check=skip_lan)
        if not ok:
            return jsonify({"success": False, "message": msg}), 400
        notifier.publish("USER_UPDATED", user_service.get_user_profile())
        return jsonify({"success": True, "message": msg, "user": user_service.get_user_profile()})

    # --- Discovery Operations ---
    @app.route("/api/peers", methods=["GET"])
    def get_peers():
        peers = discovery.get_peers()
        return jsonify({"peers": [p.to_dict() for p in peers]})

    @app.route("/api/peers/refresh", methods=["POST"])
    def refresh_peers():
        discovery.broadcast_presence()
        return jsonify({"success": True})

    @app.route("/api/peers/ping", methods=["POST"])
    def ping_peer():
        data = request.get_json() or {}
        target_ip = data.get("ip", "").strip()
        if not target_ip:
            return jsonify({"success": False, "message": "Target IP required"}), 400

        # Send unicast presence request
        discovery.ping_direct_ip(target_ip)
        return jsonify({"success": True, "message": f"Ping sent to {target_ip}"})

    # --- File/Folder Native Selection Dialogs ---
    @app.route("/api/select_file", methods=["POST"])
    def select_file_dialog():
        """Launch Windows native file open dialog."""
        selected_file = ""
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.wm_attributes("-topmost", 1)
            root.lift()
            root.focus_force()
            selected_file = filedialog.askopenfilename(
                title="Select File to Send over LAN"
            )
            root.destroy()
        except Exception as e:
            logger.debug(f"Native file dialog unavailable: {e}")

        if selected_file:
            path = Path(selected_file)
            return jsonify({
                "selected": True,
                "path": str(path.resolve()),
                "name": path.name,
                "is_folder": False,
                "size": path.stat().st_size if path.is_file() else 0,
            })
        return jsonify({"selected": False, "path": ""})

    @app.route("/api/select_folder", methods=["POST"])
    def select_folder_dialog():
        """Launch Windows native folder select dialog."""
        selected_dir = ""
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.wm_attributes("-topmost", 1)
            root.lift()
            root.focus_force()
            selected_dir = filedialog.askdirectory(
                title="Select Folder to Send over LAN"
            )
            root.destroy()
        except Exception as e:
            logger.debug(f"Native folder dialog unavailable: {e}")

        if selected_dir:
            path = Path(selected_dir)
            return jsonify({
                "selected": True,
                "path": str(path.resolve()),
                "name": path.name,
                "is_folder": True,
            })
        return jsonify({"selected": False, "path": ""})

    @app.route("/api/select_path", methods=["POST"])
    def select_path_direct():
        """Select a file or folder by direct local path string."""
        data = request.get_json() or {}
        raw = data.get("path", "").strip().strip('"').strip("'")
        if not raw:
            return jsonify({"selected": False, "message": "Path is empty."}), 400
        path = Path(raw)
        if not path.exists():
            return jsonify({"selected": False, "message": f"Path not found on disk: {raw}"}), 404
        is_folder = path.is_dir()
        size = 0
        if not is_folder and path.is_file():
            try:
                size = path.stat().st_size
            except Exception:
                size = 0
        return jsonify({
            "selected": True,
            "path": str(path.resolve()),
            "name": path.name or str(path),
            "is_folder": is_folder,
            "size": size,
        })

    # --- Transfer Operations ---
    @app.route("/api/transfers/send", methods=["POST"])
    def initiate_transfer():
        data = request.get_json() or {}
        source_path = data.get("source_path", "").strip()
        recipients = data.get("recipients", [])
        priority = data.get("priority", config.default_priority)
        is_adaptive = data.get("is_adaptive", config.adaptive_mode)

        if not source_path:
            return jsonify({"success": False, "message": "Source path is required."}), 400
        if not recipients:
            return jsonify({"success": False, "message": "Please select at least one recipient."}), 400

        try:
            dispatched = transfer_mgr.send_to_recipients(
                source_path=source_path,
                recipient_device_ids=recipients,
                priority=priority,
                is_adaptive=is_adaptive,
            )
            return jsonify({"success": True, "transfers": dispatched})
        except Exception as e:
            logger.error(f"Failed to initiate transfer: {e}")
            return jsonify({"success": False, "message": str(e)}), 400

    @app.route("/api/transfers/<transfer_id>/accept", methods=["POST"])
    def accept_transfer(transfer_id: str):
        ok = transfer_mgr.accept_incoming(transfer_id)
        return jsonify({"success": ok})

    @app.route("/api/transfers/<transfer_id>/reject", methods=["POST"])
    def reject_transfer(transfer_id: str):
        ok = transfer_mgr.reject_incoming(transfer_id)
        return jsonify({"success": ok})

    @app.route("/api/test/mock_incoming", methods=["GET", "POST"])
    def test_mock_incoming():
        """Helper endpoint for simulating incoming transfer requests via SSE."""
        data = request.get_json(silent=True) or {}
        tx_id = data.get("transfer_id", f"tx-mock-{int(time.time()*1000)}")
        notifier.publish("INCOMING_TRANSFER_REQUEST", {
            "transfer_id": tx_id,
            "sender": data.get("sender", {"username": "Alice", "hostname": "ALICE-PC", "ip": "192.168.1.101"}),
            "item_name": data.get("item_name", "Document.pdf"),
            "is_folder": data.get("is_folder", False),
            "total_bytes": data.get("total_bytes", 15400000),
            "is_resumed": data.get("is_resumed", False),
            "resume_offset": 0,
        })
        return jsonify({"success": True, "transfer_id": tx_id})

    @app.route("/api/transfers/<transfer_id>/pause", methods=["POST"])
    def pause_transfer(transfer_id: str):
        ok = transfer_mgr.pause_transfer(transfer_id)
        return jsonify({"success": ok})

    @app.route("/api/transfers/<transfer_id>/resume", methods=["POST"])
    def resume_transfer(transfer_id: str):
        ok = transfer_mgr.resume_transfer(transfer_id)
        return jsonify({"success": ok})

    @app.route("/api/transfers/<transfer_id>/cancel", methods=["POST"])
    def cancel_transfer(transfer_id: str):
        ok = transfer_mgr.cancel_transfer(transfer_id)
        return jsonify({"success": ok})

    @app.route("/api/transfers/<transfer_id>/priority", methods=["POST"])
    def update_transfer_priority(transfer_id: str):
        data = request.get_json(silent=True) or {}
        new_priority = data.get("priority", "MEDIUM")
        ok = transfer_mgr.set_transfer_priority(transfer_id, new_priority)
        return jsonify({"success": ok, "priority": str(new_priority).upper()})

    # --- Search & History ---
    @app.route("/api/transfers/history", methods=["GET"])
    def get_history():
        query = request.args.get("q", "")
        status = request.args.get("status", "")
        direction = request.args.get("direction", "")
        sort_by = request.args.get("sort_by", "date")
        sort_order = request.args.get("sort_order", "desc")
        results = search_service.search_transfers(
            query=query,
            status=status,
            direction=direction,
            sort_by=sort_by,
            sort_order=sort_order,
        )
        return jsonify({"transfers": results})

    @app.route("/api/files/downloaded", methods=["GET"])
    def get_downloaded_files():
        query = request.args.get("q", "")
        files = search_service.list_downloaded_files(search_query=query)
        return jsonify({
            "download_dir": str(config.download_dir),
            "files": files,
        })

    @app.route("/api/files/open_explorer", methods=["POST"])
    def open_in_explorer():
        """Open Windows Explorer to reveal a received file or open download folder."""
        data = request.get_json(silent=True) or {}
        raw_path = str(data.get("path", "")).strip().strip('"').strip("'")
        file_name = str(data.get("file_name", "")).strip().strip('"').strip("'")

        dl_dir = config.download_dir.resolve()
        target = None

        if raw_path:
            p = Path(raw_path)
            if p.exists():
                target = p
            elif (dl_dir / raw_path).exists():
                target = dl_dir / raw_path

        if not target and file_name:
            candidate = dl_dir / file_name
            if candidate.exists():
                target = candidate

        if not target:
            target = dl_dir

        try:
            if sys.platform == "win32":
                import subprocess
                if target.is_file():
                    subprocess.Popen(["explorer", f"/select,{str(target)}"])
                else:
                    os.startfile(str(target))
            elif sys.platform == "darwin":
                import subprocess
                if target.is_file():
                    subprocess.Popen(["open", "-R", str(target)])
                else:
                    subprocess.Popen(["open", str(target)])
            else:
                import subprocess
                folder = target.parent if target.is_file() else target
                subprocess.Popen(["xdg-open", str(folder)])
            return jsonify({"success": True, "path": str(target)})
        except Exception as e:
            logger.error(f"Failed to open in explorer: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    # --- Research Metrics ---
    @app.route("/api/research/metrics", methods=["GET"])
    def get_research_metrics():
        metrics = database.get_research_metrics(limit=50)
        return jsonify({"metrics": metrics})

    # --- Settings ---
    @app.route("/api/settings", methods=["GET", "POST"])
    def handle_settings():
        if request.method == "GET":
            return jsonify(config.to_dict())

        data = request.get_json() or {}
        new_dl_dir = data.get("download_dir")
        if new_dl_dir:
            try:
                config.set_download_dir(new_dl_dir)
            except Exception as e:
                return jsonify({"success": False, "message": f"Invalid download path: {e}"}), 400

        if "bandwidth_limit_mbps" in data:
            config.bandwidth_limit_mbps = float(data["bandwidth_limit_mbps"])
            transfer_mgr.bandwidth_ctrl.set_limit(config.bandwidth_limit_mbps)

        if "default_priority" in data:
            config.default_priority = str(data["default_priority"]).upper()

        if "adaptive_mode" in data:
            config.adaptive_mode = bool(data["adaptive_mode"])

        config.save()
        notifier.publish("SETTINGS_UPDATED", config.to_dict())
        return jsonify({"success": True, "settings": config.to_dict()})

    @app.route("/api/settings/choose_download_dir", methods=["POST"])
    def choose_download_dir_dialog():
        """Interactive folder chooser for download location."""
        selected_dir = ""
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.wm_attributes("-topmost", 1)
            root.lift()
            root.focus_force()
            selected_dir = filedialog.askdirectory(
                title="Choose LAN File Sharing Download Directory"
            )
            root.destroy()
        except Exception as e:
            logger.debug(f"Dialog unavailable: {e}")

        if selected_dir:
            config.set_download_dir(selected_dir)
            notifier.publish("SETTINGS_UPDATED", config.to_dict())
            return jsonify({"selected": True, "download_dir": str(config.download_dir)})
        return jsonify({"selected": False, "download_dir": str(config.download_dir)})

    return app
