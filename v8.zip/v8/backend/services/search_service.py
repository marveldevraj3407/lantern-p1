"""File and transfer history search service."""

from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path
from typing import Any, Dict, List

from backend.config import AppConfig
from backend.database import Database


class SearchService:
    """Provides querying over transfer history and downloaded files in the user's download directory."""

    def __init__(self, config: AppConfig, database: Database) -> None:
        self.config = config
        self.db = database

    def search_transfers(
        self,
        query: str = "",
        status: str = "",
        direction: str = "",
        sort_by: str = "date",
        sort_order: str = "desc",
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """Search and sort transfer history metadata."""
        return self.db.list_transfers(
            search_query=query,
            status_filter=status,
            direction_filter=direction,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
            offset=offset,
        )

    def list_downloaded_files(self, search_query: str = "") -> List[Dict[str, Any]]:
        """List files currently located in the user's configured download directory.

        Never inspects or accesses project files.
        """
        results: List[Dict[str, Any]] = []
        dl_dir = self.config.download_dir.resolve()

        if not dl_dir.exists():
            return results

        clean_query = search_query.strip().lower()

        try:
            for root, _, filenames in os.walk(dl_dir):
                for fname in filenames:
                    if clean_query and clean_query not in fname.lower():
                        continue
                    full_path = Path(root) / fname
                    try:
                        stat = full_path.stat()
                        rel_path = str(full_path.relative_to(dl_dir)).replace("\\", "/")
                        results.append({
                            "name": fname,
                            "relative_path": rel_path,
                            "extension": full_path.suffix.lower(),
                            "size_bytes": stat.st_size,
                            "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                            "absolute_path": str(full_path),
                        })
                    except (OSError, PermissionError):
                        continue
        except Exception:
            pass

        # Sort newest first
        results.sort(key=lambda x: x["modified_at"], reverse=True)
        return results
