"""File chunking and folder scanning operations.

CRITICAL RULE:
Files must be read directly from their original location.
Never copy source files into the project or duplicate disk data.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Generator, List, Tuple

from backend.models import FileItem
from backend.transfer.integrity import compute_file_sha256
from backend.transfer.security import sanitize_filename


def scan_source_item(source_path: Path | str, compute_hashes: bool = False) -> Tuple[str, bool, int, List[FileItem]]:
    """Scan a file or folder at source_path without copying any data.

    Returns:
        (item_name, is_folder, total_bytes, files_list)
    """
    path = Path(source_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Source path does not exist: {source_path}")

    item_name = path.name
    files: List[FileItem] = []
    total_bytes = 0

    if path.is_file():
        is_folder = False
        size = path.stat().st_size
        sha = compute_file_sha256(path) if compute_hashes else ""
        files.append(FileItem(relative_path=item_name, size=size, sha256=sha))
        total_bytes = size
    elif path.is_dir():
        is_folder = True
        for root, _, filenames in os.walk(path):
            for fname in filenames:
                file_abs = Path(root) / fname
                try:
                    rel = file_abs.relative_to(path)
                    # Convert to forward slashes for cross-platform consistency
                    rel_str = str(rel).replace("\\", "/")
                    size = file_abs.stat().st_size
                    sha = compute_file_sha256(file_abs) if compute_hashes else ""
                    files.append(FileItem(relative_path=rel_str, size=size, sha256=sha))
                    total_bytes += size
                except (OSError, PermissionError) as e:
                    continue
    else:
        raise ValueError(f"Path is neither a regular file nor directory: {source_path}")

    return item_name, is_folder, total_bytes, files


def stream_file_chunks(
    file_path: Path | str,
    chunk_size: int = 65536,
    start_offset: int = 0,
) -> Generator[Tuple[int, int, bytes, str], None, None]:
    """Stream chunks from file starting at start_offset.

    Yields:
        (chunk_index, offset, chunk_bytes, chunk_sha256)
    """
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {file_path}")

    with open(path, "rb") as f:
        f.seek(start_offset)
        offset = start_offset
        chunk_index = start_offset // chunk_size

        while True:
            data = f.read(chunk_size)
            if not data:
                break
            chunk_hash = hashlib.sha256(data).hexdigest()
            yield chunk_index, offset, data, chunk_hash
            offset += len(data)
            chunk_index += 1
