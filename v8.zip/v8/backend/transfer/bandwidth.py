"""Priority scheduling and bandwidth controller."""

from __future__ import annotations

import threading
import time
from typing import Dict

PRIORITY_WEIGHTS = {
    "HIGH": 4.0,
    "MEDIUM": 2.0,
    "LOW": 1.0,
}


class BandwidthController:
    """Manages transmission pacing and resource fairness based on transfer priorities."""

    def __init__(self, limit_mbps: float = 0.0) -> None:
        self.limit_mbps = limit_mbps
        self._active_transfers: Dict[str, str] = {}  # transfer_id -> priority
        self._lock = threading.Lock()

    def set_limit(self, limit_mbps: float) -> None:
        self.limit_mbps = max(0.0, limit_mbps)

    def register_transfer(self, transfer_id: str, priority: str) -> None:
        with self._lock:
            self._active_transfers[transfer_id] = priority.upper()

    def update_priority(self, transfer_id: str, new_priority: str) -> None:
        with self._lock:
            self._active_transfers[transfer_id] = new_priority.upper()

    def get_priority(self, transfer_id: str) -> str:
        with self._lock:
            return self._active_transfers.get(transfer_id, "MEDIUM")

    def unregister_transfer(self, transfer_id: str) -> None:
        with self._lock:
            self._active_transfers.pop(transfer_id, None)

    def get_active_count(self) -> int:
        with self._lock:
            return len(self._active_transfers)

    def pace_chunk(self, transfer_id: str, chunk_bytes: int) -> None:
        """Introduce fine-grained sleep based on real-time transfer priority (FDM-style)."""
        with self._lock:
            active_count = len(self._active_transfers)
            priority = self._active_transfers.get(transfer_id, "MEDIUM")

        if active_count == 0:
            return

        if self.limit_mbps <= 0.0:
            # Free Download Manager style dynamic prioritization without global bandwidth cap:
            # LOW: Background pacing to leave pipe free for other applications or HIGH transfers
            # MEDIUM: Balanced fair transfer
            # HIGH: Uncapped maximum throughput
            if priority == "LOW":
                time.sleep(0.015)
            elif priority == "MEDIUM" and active_count > 1:
                time.sleep(0.002)
            return

        # Calculate weight fraction when global bandwidth limit is enforced
        weight = PRIORITY_WEIGHTS.get(priority, 2.0)
        total_weight = sum(PRIORITY_WEIGHTS.get(p, 2.0) for p in self._active_transfers.values()) or 1.0
        allocated_mbps = self.limit_mbps * (weight / total_weight)

        # Minimum delay based on allocated bits per second
        allocated_bytes_per_sec = (allocated_mbps * 1024 * 1024) / 8.0
        if allocated_bytes_per_sec > 0:
            ideal_delay = chunk_bytes / allocated_bytes_per_sec
            if ideal_delay > 0.001:
                time.sleep(min(ideal_delay, 1.0))

