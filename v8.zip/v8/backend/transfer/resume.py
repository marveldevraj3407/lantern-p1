"""Resume tracker and partial transfer journal manager.

CRITICAL RULES:
1. Incomplete downloads live in AppData/partial_transfers, NOT the project folder.
2. Completed files are moved directly into the user's configured download folder.
3. Clean up partial files and manifests upon completion or cancellation.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
import shutil
import time
from typing import Any, Dict, List, Optional, Tuple

from backend.models import FileItem
from backend.transfer.integrity import compute_file_sha256
from backend.transfer.security import resolve_safe_target_path

logger = logging.getLogger("ResumeManager")


class PartialTransferSession:
    """Manages writing chunks, state persistence, and final reassembly for a transfer."""

    _active_sessions: Dict[str, PartialTransferSession] = {}

    def __init__(
        self,
        transfer_id: str,
        partial_base_dir: Path,
        download_base_dir: Path,
        item_name: str,
        is_folder: bool,
        files: List[FileItem],
    ) -> None:
        self.transfer_id = transfer_id
        self.partial_base_dir = partial_base_dir
        self.download_base_dir = download_base_dir
        self.item_name = item_name
        self.is_folder = is_folder
        self.files = files

        # If an earlier session for this transfer_id is still active, close and flush it
        prev = self._active_sessions.pop(transfer_id, None)
        if prev and prev is not self:
            prev.close()
        self._active_sessions[transfer_id] = self

        self.session_dir = self.partial_base_dir / self.transfer_id
        self.manifest_path = self.session_dir / "manifest.json"
        self._last_manifest_save = time.time()
        self._open_files: Dict[int, Any] = {}
        self._file_positions: Dict[int, int] = {}
        self._init_session()
        self._manifest = self._load_manifest()

    def __del__(self) -> None:
        self.close()

    def _init_session(self) -> None:
        """Create session directory and manifest if not existing."""
        self.session_dir.mkdir(parents=True, exist_ok=True)
        if not self.manifest_path.exists():
            self._save_manifest({
                "transfer_id": self.transfer_id,
                "item_name": self.item_name,
                "is_folder": self.is_folder,
                "files": [
                    {
                        "index": idx,
                        "relative_path": f.relative_path,
                        "size": f.size,
                        "sha256": f.sha256,
                        "bytes_written": 0,
                        "is_complete": False,
                    }
                    for idx, f in enumerate(self.files)
                ],
            })

    def _load_manifest(self) -> Dict[str, Any]:
        with open(self.manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _save_manifest(self, data: Dict[str, Any]) -> None:
        with open(self.manifest_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def get_part_file_path(self, file_index: int) -> Path:
        """Return the .part path for file at index."""
        return self.session_dir / f"file_{file_index}.part"

    def close(self) -> None:
        """Persist manifest to disk and flush/close open file handles."""
        if hasattr(self, "_open_files"):
            for f in list(self._open_files.values()):
                try:
                    if not f.closed:
                        f.flush()
                        f.close()
                except Exception:
                    pass
            self._open_files.clear()
        if hasattr(self, "_file_positions"):
            self._file_positions.clear()

        if hasattr(self, "_manifest"):
            try:
                self._save_manifest(self._manifest)
            except Exception:
                pass

    def get_resume_offset(self, file_index: int) -> int:
        """Get the byte offset already downloaded for file at index."""
        if hasattr(self, "_open_files") and file_index in self._open_files:
            try:
                self._open_files[file_index].flush()
            except Exception:
                pass
        if hasattr(self, "_manifest") and 0 <= file_index < len(self._manifest.get("files", [])):
            written = self._manifest["files"][file_index].get("bytes_written", 0)
            if written > 0:
                return written
        part_path = self.get_part_file_path(file_index)
        if not part_path.exists():
            return 0
        return part_path.stat().st_size

    def write_chunk(self, file_index: int, offset: int, data: bytes) -> int:
        """Write a chunk of binary data to the part file at specified offset with high performance.

        Returns new total bytes in part file.
        """
        if file_index not in self._open_files or self._open_files[file_index].closed:
            part_path = self.get_part_file_path(file_index)
            mode = "r+b" if part_path.exists() else "w+b"
            self._open_files[file_index] = open(part_path, mode, buffering=4 * 1024 * 1024)

        f = self._open_files[file_index]
        if self._file_positions.get(file_index) != offset:
            f.seek(offset)
        f.write(data)
        self._file_positions[file_index] = offset + len(data)

        chunk_len = len(data)
        cur_written = offset + chunk_len

        # Update in-memory manifest; persist to disk on file completion or every 1.0 second
        if 0 <= file_index < len(self._manifest["files"]):
            f_info = self._manifest["files"][file_index]
            if cur_written > f_info.get("bytes_written", 0):
                f_info["bytes_written"] = cur_written
            expected_size = f_info.get("size", 0)
            now = time.time()
            if cur_written >= expected_size:
                f_info["is_complete"] = True
                f.flush()
                try:
                    f.close()
                except Exception:
                    pass
                self._open_files.pop(file_index, None)
                self._save_manifest(self._manifest)
                self._last_manifest_save = now
            elif now - self._last_manifest_save >= 1.0:
                f.flush()
                self._save_manifest(self._manifest)
                self._last_manifest_save = now
            return f_info["bytes_written"]

        return cur_written

    def update_expected_hashes(self, file_hashes: Dict[Any, str]) -> None:
        """Update expected file hashes received from sender upon stream completion."""
        if hasattr(self, "_manifest") and "files" in self._manifest and file_hashes:
            for idx_key, sha in file_hashes.items():
                try:
                    idx = int(idx_key)
                    if 0 <= idx < len(self._manifest["files"]):
                        self._manifest["files"][idx]["sha256"] = sha
                except (ValueError, TypeError):
                    continue
            self._save_manifest(self._manifest)

    def finalize_and_verify(self) -> Tuple[bool, str]:
        """Verify SHA-256 for all completed parts and move them to the download directory.

        Returns (success, message).
        """
        self.close()
        manifest = self._load_manifest()
        # 1. Verify all parts match expected SHA-256
        for file_info in manifest["files"]:
            idx = file_info["index"]
            expected_sha = file_info.get("sha256")
            expected_size = file_info["size"]
            part_path = self.get_part_file_path(idx)

            if not part_path.exists():
                return False, f"Missing part file for index {idx}"

            actual_size = part_path.stat().st_size
            if actual_size != expected_size:
                return False, f"Size mismatch for {file_info['relative_path']}: expected {expected_size}, got {actual_size}"

            if expected_sha:
                actual_sha = compute_file_sha256(part_path)
                if actual_sha.lower() != expected_sha.lower():
                    return False, f"SHA-256 integrity failed for {file_info['relative_path']}"

        # 2. Move files to target download directory
        for file_info in manifest["files"]:
            idx = file_info["index"]
            rel_path = file_info["relative_path"]
            part_path = self.get_part_file_path(idx)

            if self.is_folder:
                # Place inside folder: download_dir / item_name / rel_path
                full_rel = f"{self.item_name}/{rel_path}"
            else:
                full_rel = rel_path

            dest_path = resolve_safe_target_path(self.download_base_dir, full_rel)
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            # Move part file to final destination
            if dest_path.exists():
                try:
                    dest_path.unlink()
                except Exception:
                    pass
            shutil.move(str(part_path), str(dest_path))

        # 3. Clean up session temp directory
        self.cleanup()
        return True, "All files verified and saved successfully"

    def cleanup(self) -> None:
        """Remove session partial files."""
        self.close()
        if self.session_dir.exists():
            try:
                shutil.rmtree(self.session_dir, ignore_errors=True)
            except Exception as e:
                logger.warning(f"Failed to clean up partial directory {self.session_dir}: {e}")
