"""Transfer orchestrator managing active sessions, multi-recipient distribution, and life-cycles."""

from __future__ import annotations

import logging
from pathlib import Path
import threading
import uuid
from typing import Any, Dict, List, Optional

from backend.config import AppConfig
from backend.database import Database
from backend.models import Peer, TransferJob
from backend.networking.discovery import DiscoveryService
from backend.networking.tcp_client import TransferSender
from backend.networking.tcp_server import TCPServer
from backend.services.notification_service import NotificationBus
from backend.transfer.bandwidth import BandwidthController
from backend.transfer.chunking import scan_source_item

logger = logging.getLogger("TransferManager")


class TransferManager:
    """Coordinates sending to multiple recipients, incoming accept/reject, and worker threads."""

    def __init__(
        self,
        config: AppConfig,
        database: Database,
        notifier: NotificationBus,
        discovery: DiscoveryService,
        tcp_server: TCPServer,
    ) -> None:
        self.config = config
        self.db = database
        self.notifier = notifier
        self.discovery = discovery
        self.tcp_server = tcp_server

        self.bandwidth_ctrl = BandwidthController(limit_mbps=self.config.bandwidth_limit_mbps)
        self._senders: Dict[str, TransferSender] = {}
        self._transfer_meta: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def send_to_recipients(
        self,
        source_path: str,
        recipient_device_ids: List[str],
        priority: str = "MEDIUM",
        is_adaptive: bool = True,
    ) -> List[Dict[str, Any]]:
        """Initiate transfer of a source file or folder to multiple recipients independently."""
        path = Path(source_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"Selected path does not exist: {source_path}")

        # Scan source item ONCE without copying to disk
        item_name, is_folder, total_bytes, files = scan_source_item(path)
        logger.info(f"Initiating transfer of '{item_name}' ({total_bytes} bytes, {len(files)} files) to {len(recipient_device_ids)} recipients")

        peers_map = {p.device_id: p for p in self.discovery.get_peers()}
        results = []

        for dev_id in recipient_device_ids:
            peer = peers_map.get(dev_id)
            if not peer:
                logger.warning(f"Recipient device {dev_id} not found in peer registry")
                continue

            transfer_id = f"tx_{uuid.uuid4().hex[:12]}"
            with self._lock:
                self._transfer_meta[transfer_id] = {
                    "source_path": str(path),
                    "priority": priority,
                    "is_adaptive": is_adaptive,
                    "peer_device_id": dev_id,
                }

            sender = TransferSender(
                config=self.config,
                database=self.db,
                notifier=self.notifier,
                bandwidth_ctrl=self.bandwidth_ctrl,
                transfer_id=transfer_id,
                peer=peer,
                source_path=path,
                item_name=item_name,
                is_folder=is_folder,
                files=files,
                total_bytes=total_bytes,
                priority=priority,
                is_adaptive=is_adaptive,
            )

            with self._lock:
                self._senders[transfer_id] = sender

            # Spawn independent sender thread per recipient
            thread = threading.Thread(
                target=self._run_sender_thread,
                args=(transfer_id, sender),
                daemon=True,
                name=f"Sender-{transfer_id}",
            )
            thread.start()

            results.append({
                "transfer_id": transfer_id,
                "recipient_username": peer.username,
                "recipient_hostname": peer.hostname,
                "status": "PENDING",
            })

        return results

    def _run_sender_thread(self, transfer_id: str, sender: TransferSender) -> None:
        try:
            sender.run()
        finally:
            with self._lock:
                self._senders.pop(transfer_id, None)

    def pause_transfer(self, transfer_id: str) -> bool:
        """Pause active outgoing or incoming transfer."""
        with self._lock:
            sender = self._senders.get(transfer_id)
        if sender:
            return sender.pause()
        return self.tcp_server.pause_transfer(transfer_id)

    def resume_transfer(self, transfer_id: str) -> bool:
        """Resume paused outgoing or incoming transfer."""
        with self._lock:
            sender = self._senders.get(transfer_id)
        if sender:
            return sender.resume()

        if self.tcp_server.resume_transfer(transfer_id):
            return True

        # If sender thread exited while paused, restart sender to resume from byte offset
        tx = self.db.get_transfer(transfer_id)
        if tx and tx.get("direction") == "OUTGOING":
            meta = {}
            with self._lock:
                meta = self._transfer_meta.get(transfer_id, {})
            source_path = meta.get("source_path")
            if not source_path:
                return False

            path = Path(source_path)
            if not path.exists():
                return False

            peer_id = tx.get("peer_device_id")
            peers_map = {p.device_id: p for p in self.discovery.get_peers()}
            peer = peers_map.get(peer_id)
            if not peer:
                peer = Peer(
                    device_id=peer_id,
                    username=tx.get("peer_username", "Unknown"),
                    hostname=tx.get("peer_hostname", "Unknown"),
                    ip=tx.get("peer_ip", "127.0.0.1"),
                    tcp_port=self.config.transfer_port,
                )

            item_name, is_folder, total_bytes, files = scan_source_item(path)
            new_sender = TransferSender(
                config=self.config,
                database=self.db,
                notifier=self.notifier,
                bandwidth_ctrl=self.bandwidth_ctrl,
                transfer_id=transfer_id,
                peer=peer,
                source_path=path,
                item_name=item_name,
                is_folder=is_folder,
                files=files,
                total_bytes=total_bytes,
                priority=tx.get("priority", "MEDIUM"),
                is_adaptive=meta.get("is_adaptive", True),
            )
            with self._lock:
                self._senders[transfer_id] = new_sender

            thread = threading.Thread(
                target=self._run_sender_thread,
                args=(transfer_id, new_sender),
                daemon=True,
                name=f"Sender-{transfer_id}",
            )
            thread.start()
            return True

        return False

    def cancel_transfer(self, transfer_id: str) -> bool:
        """Cancel active outgoing or incoming transfer."""
        with self._lock:
            sender = self._senders.get(transfer_id)
        if sender:
            return sender.cancel()
        return self.tcp_server.cancel_transfer(transfer_id)

    def set_transfer_priority(self, transfer_id: str, priority: str) -> bool:
        """Update transfer priority in real-time (Free Download Manager style)."""
        norm = priority.upper()
        if norm not in ("HIGH", "MEDIUM", "LOW"):
            return False

        with self._lock:
            sender = self._senders.get(transfer_id)
            if transfer_id in self._transfer_meta:
                self._transfer_meta[transfer_id]["priority"] = norm

        if sender:
            return sender.set_priority(norm)

        # Delegate to TCPServer for incoming transfers
        return self.tcp_server.set_priority(transfer_id, norm)

    def accept_incoming(self, transfer_id: str) -> bool:
        """User accepted incoming transfer request."""
        return self.tcp_server.resolve_pending_request(transfer_id, accept=True)

    def reject_incoming(self, transfer_id: str) -> bool:
        """User rejected incoming transfer request."""
        return self.tcp_server.resolve_pending_request(transfer_id, accept=False)
