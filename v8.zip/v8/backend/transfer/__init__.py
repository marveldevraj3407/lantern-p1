"""Transfer package for chunking, resume, hashing, adaptive algorithm, and bandwidth allocation."""
