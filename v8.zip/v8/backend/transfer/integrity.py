"""Streaming cryptographic integrity verification using SHA-256."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Callable, Optional


def compute_file_sha256(
    file_path: Path | str,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    buffer_size: int = 2 * 1024 * 1024,
) -> str:
    """Compute SHA-256 of a file in streams without loading it all into RAM.

    Args:
        file_path: Path to the target file.
        progress_callback: Optional callback(bytes_read, total_bytes).
        buffer_size: Read buffer size in bytes (default: 64 KB).

    Returns:
        Hex-encoded SHA-256 digest string.
    """
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"File not found: {file_path}")

    total_size = path.stat().st_size
    bytes_read = 0
    hasher = hashlib.sha256()

    with open(path, "rb") as f:
        while True:
            chunk = f.read(buffer_size)
            if not chunk:
                break
            hasher.update(chunk)
            bytes_read += len(chunk)
            if progress_callback:
                progress_callback(bytes_read, total_size)

    return hasher.hexdigest()


def verify_file_integrity(file_path: Path | str, expected_sha256: str) -> bool:
    """Verify that a file's SHA-256 matches expected_sha256.

    Returns True if valid, False otherwise.
    """
    if not expected_sha256:
        return False
    actual_sha256 = compute_file_sha256(file_path)
    return actual_sha256.lower() == expected_sha256.strip().lower()
