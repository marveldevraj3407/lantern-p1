"""Adaptive chunk sizing and research metric recording engine.

Evaluates:
  BASELINE: Fixed-size TCP chunk transfer (e.g. 64 KB constant)
  vs
  PROPOSED: Dynamic AIMD-style adaptive chunk scaling based on RTT,
            ACK latency, throughput gradients, and active concurrency.
"""

from __future__ import annotations

from datetime import datetime
import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("AdaptiveEngine")


class AdaptiveEngine:
    """Calculates optimal chunk size and tracks research experimentation metrics."""

    MIN_CHUNK_SIZE = 32 * 1024       # 32 KB
    INITIAL_CHUNK_SIZE = 64 * 1024   # 64 KB
    MAX_CHUNK_SIZE = 4 * 1024 * 1024 # 4 MB

    # Thresholds for decision making
    RTT_STABLE_THRESHOLD_MS = 60.0
    RTT_CONGESTION_THRESHOLD_MS = 150.0

    def __init__(self, transfer_id: str, is_adaptive: bool = True) -> None:
        self.transfer_id = transfer_id
        self.is_adaptive = is_adaptive

        self.current_chunk_size = self.INITIAL_CHUNK_SIZE
        self.min_chunk_observed = self.current_chunk_size
        self.max_chunk_observed = self.current_chunk_size

        self.start_time = time.time()
        self.total_chunks = 0
        self.retry_count = 0
        self.retransmitted_bytes = 0

        self.rtt_history: List[float] = []
        self.throughput_samples: List[float] = []  # MB/s
        self.decision_logs: List[Dict[str, Any]] = []

    def start_streaming(self) -> None:
        """Reset start time when actual chunk streaming begins to exclude user modal approval delay."""
        self.start_time = time.time()

    def get_next_chunk_size(self) -> int:
        """Return the chunk size to use for the next packet."""
        if not self.is_adaptive:
            return self.INITIAL_CHUNK_SIZE
        return self.current_chunk_size

    def record_chunk_ack(
        self,
        chunk_bytes: int,
        rtt_ms: float,
        success: bool = True,
        concurrency: int = 1,
    ) -> None:
        """Process ACK feedback and dynamically adjust chunk size."""
        self.total_chunks += 1
        self.rtt_history.append(rtt_ms)

        # Calculate instantaneous throughput in MB/s
        sec = max(rtt_ms / 1000.0, 0.0001)
        instant_mbps = (chunk_bytes / (1024 * 1024)) / sec
        self.throughput_samples.append(instant_mbps)

        if not self.is_adaptive:
            return

        prev_size = self.current_chunk_size
        decision_reason = ""

        # Normalize RTT against baseline 64KB chunk so that chunk serialization delay
        # (e.g. transmitting a 1-4 MB chunk over Wi-Fi) is not misinterpreted as network congestion
        chunk_factor = max(chunk_bytes / self.INITIAL_CHUNK_SIZE, 1.0)
        norm_rtt = rtt_ms / chunk_factor

        # Detect if throughput actually dropped compared to previous chunk
        prev_throughput = self.throughput_samples[-2] if len(self.throughput_samples) >= 2 else instant_mbps
        throughput_dropped = instant_mbps < (prev_throughput * 0.85)

        # Distinguish between full chunks and partial/tail chunks of files in folders
        is_full_chunk = chunk_bytes >= int(self.current_chunk_size * 0.75)

        if not success:
            # Drop/failure: aggressively halve chunk size
            self.retry_count += 1
            self.retransmitted_bytes += chunk_bytes
            self.current_chunk_size = max(self.MIN_CHUNK_SIZE, self.current_chunk_size // 2)
            decision_reason = f"Chunk transmission failed. Throttled down from {prev_size // 1024}KB to {self.current_chunk_size // 1024}KB."

        elif not is_full_chunk:
            # Tail chunk of a file or small file in a folder: retain current scaling for the next file
            pass

        elif ((rtt_ms >= 200.0 and norm_rtt >= 15.0 and throughput_dropped) or (rtt_ms >= 1500.0)) or concurrency > 3:
            # Actual network congestion (throughput dropped while latency spiked) or high concurrency
            self.current_chunk_size = max(self.MIN_CHUNK_SIZE, int(self.current_chunk_size * 0.75))
            decision_reason = f"Network congestion ({rtt_ms:.1f}ms, norm {norm_rtt:.1f}ms, {instant_mbps:.1f}MB/s) or concurrency ({concurrency}). Decreased chunk size to {self.current_chunk_size // 1024}KB."

        else:
            # Healthy channel feedback: scale chunk size up towards MAX_CHUNK_SIZE
            # Ramp up by 2x to rapidly overcome Wi-Fi/LAN RTT latency
            self.current_chunk_size = min(self.MAX_CHUNK_SIZE, self.current_chunk_size * 2)

            if self.current_chunk_size != prev_size:
                decision_reason = f"Channel stable (RTT {rtt_ms:.1f}ms, norm {norm_rtt:.1f}ms, {instant_mbps:.1f}MB/s). Scaled chunk up from {prev_size // 1024}KB to {self.current_chunk_size // 1024}KB."

        self.min_chunk_observed = min(self.min_chunk_observed, self.current_chunk_size)
        self.max_chunk_observed = max(self.max_chunk_observed, self.current_chunk_size)

        if decision_reason:
            log_entry = {
                "time_sec": round(time.time() - self.start_time, 2),
                "rtt_ms": round(rtt_ms, 2),
                "instant_mbps": round(instant_mbps, 2),
                "chunk_size_kb": self.current_chunk_size // 1024,
                "reason": decision_reason,
            }
            self.decision_logs.append(log_entry)
            logger.debug(f"[{self.transfer_id}] {decision_reason}")

    def generate_research_metrics(self, total_bytes: int) -> Dict[str, Any]:
        """Compile comprehensive research metrics for database storage and graphs."""
        total_time = max(time.time() - self.start_time, 0.001)
        avg_throughput = (total_bytes / (1024 * 1024)) / total_time
        peak_throughput = max(self.throughput_samples) if self.throughput_samples else avg_throughput
        avg_rtt = sum(self.rtt_history) / len(self.rtt_history) if self.rtt_history else 0.0

        return {
            "transfer_id": self.transfer_id,
            "mode": "ADAPTIVE" if self.is_adaptive else "BASELINE_FIXED",
            "file_size": total_bytes,
            "total_time_seconds": round(total_time, 3),
            "avg_throughput_mbps": round(avg_throughput, 2),
            "peak_throughput_mbps": round(peak_throughput, 2),
            "chunk_size_min": self.min_chunk_observed,
            "chunk_size_max": self.max_chunk_observed,
            "chunk_size_final": self.current_chunk_size,
            "total_chunks": self.total_chunks,
            "retry_count": self.retry_count,
            "retransmitted_bytes": self.retransmitted_bytes,
            "rtt_avg_ms": round(avg_rtt, 2),
            "timestamp": datetime.now().isoformat(),
            "decision_logs": self.decision_logs,
        }
