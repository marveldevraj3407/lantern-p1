"""TCP server for incoming transfer requests, interactive accept/reject, and chunk receiving."""

from __future__ import annotations

from datetime import datetime
import hashlib
import logging
from pathlib import Path
import select
import socket
import threading
import time
from typing import Any, Dict, Optional

from backend.config import AppConfig
from backend.database import Database
from backend.models import FileItem, TransferJob
from backend.networking.protocol import (
    decode_packet_from_socket,
    encode_packet,
    send_framed_packet,
    MSG_CHUNK,
    MSG_CHUNK_ACK,
    MSG_TRANSFER_CANCEL,
    MSG_TRANSFER_COMPLETE,
    MSG_TRANSFER_FAILED,
    MSG_TRANSFER_PAUSE,
    MSG_TRANSFER_REQUEST,
    MSG_TRANSFER_RESPONSE,
    MSG_TRANSFER_RESUME,
    ProtocolError,
)
from backend.services.notification_service import NotificationBus
from backend.transfer.resume import PartialTransferSession
from backend.transfer.security import sanitize_filename

logger = logging.getLogger("TCPServer")


class TCPServer:
    """Listens for incoming TCP file transfer requests and receives streamed file chunks."""

    REQUEST_TIMEOUT_SEC = 60.0  # seconds to wait for receiver UI to Accept or Reject

    def __init__(
        self,
        config: AppConfig,
        database: Database,
        notifier: NotificationBus,
        discovery: Optional[Any] = None,
    ) -> None:
        self.config = config
        self.db = database
        self.notifier = notifier
        self.discovery = discovery

        self._server_sock: Optional[socket.socket] = None
        self._running = False
        self._listen_thread: Optional[threading.Thread] = None

        # Pending user decisions for incoming requests: transfer_id -> (Event, result_dict)
        self._pending_decisions: Dict[str, Dict[str, Any]] = {}
        # Active receiving sessions: transfer_id -> context dict
        self._active_receivers: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def pause_transfer(self, transfer_id: str) -> bool:
        """Pause an active receiving transfer."""
        with self._lock:
            ctx = self._active_receivers.get(transfer_id)
            if not ctx:
                return False
            ctx["is_paused"] = True
            ctx["pause_event"].clear()
            try:
                if ctx.get("sock"):
                    pause_pkt = encode_packet({"type": MSG_TRANSFER_PAUSE, "transfer_id": transfer_id})
                    ctx["sock"].sendall(pause_pkt)
            except Exception:
                pass
        self.db.update_transfer_status(
            transfer_id, "PAUSED", transferred_bytes=ctx.get("transferred_bytes", 0)
        )
        self.notifier.publish("TRANSFER_PAUSED", {
            "transfer_id": transfer_id,
            "direction": "INCOMING",
            "transferred_bytes": ctx.get("transferred_bytes", 0),
            "total_bytes": ctx.get("total_bytes", 0),
        })
        return True

    def resume_transfer(self, transfer_id: str) -> bool:
        """Resume an active receiving transfer."""
        with self._lock:
            ctx = self._active_receivers.get(transfer_id)
            if not ctx:
                return False
            ctx["is_paused"] = False
            ctx["pause_event"].set()
            try:
                if ctx.get("sock"):
                    resume_pkt = encode_packet({"type": MSG_TRANSFER_RESUME, "transfer_id": transfer_id})
                    ctx["sock"].sendall(resume_pkt)
            except Exception:
                pass
        self.db.update_transfer_status(transfer_id, "IN_PROGRESS")
        self.notifier.publish("TRANSFER_RESUMED", {
            "transfer_id": transfer_id,
            "direction": "INCOMING",
        })
        return True

    def cancel_transfer(self, transfer_id: str) -> bool:
        """Cancel an active receiving transfer."""
        with self._lock:
            ctx = self._active_receivers.get(transfer_id)
            if not ctx:
                return False
            ctx["is_cancelled"] = True
            ctx["pause_event"].set()
            try:
                cancel_pkt = encode_packet({"type": MSG_TRANSFER_CANCEL, "transfer_id": transfer_id})
                ctx["sock"].sendall(cancel_pkt)
                ctx["sock"].close()
            except Exception:
                pass
        self.db.update_transfer_status(transfer_id, "CANCELLED", "Transfer cancelled by user")
        self.notifier.publish("TRANSFER_CANCELLED", {
            "transfer_id": transfer_id,
            "direction": "INCOMING",
            "error": "Transfer cancelled by user",
        })
        return True

    def set_priority(self, transfer_id: str, new_priority: str) -> bool:
        """Update transfer priority (Free Download Manager style)."""
        norm = new_priority.upper()
        if norm not in ("HIGH", "MEDIUM", "LOW"):
            return False
        with self._lock:
            ctx = self._active_receivers.get(transfer_id)
            if ctx:
                ctx["priority"] = norm
        try:
            self.db.update_transfer_priority(transfer_id, norm)
        except Exception as exc:
            logger.warning(f"Failed to update transfer priority in db: {exc}")
        self.notifier.publish("TRANSFER_PRIORITY_UPDATED", {
            "transfer_id": transfer_id,
            "direction": "INCOMING",
            "priority": norm,
        })
        return True

    def start(self) -> None:
        """Bind TCP socket and start listener loop."""
        if self._running:
            return

        self._running = True
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        try:
            self._server_sock.bind(("0.0.0.0", self.config.transfer_port))
            self._server_sock.listen(10)
            logger.info(f"TCP Transfer Server listening on port {self.config.transfer_port}")
        except Exception as e:
            logger.error(f"Failed to bind TCP server on port {self.config.transfer_port}: {e}")
            self._running = False
            return

        self._listen_thread = threading.Thread(
            target=self._accept_loop, name="TCPServer-Accept", daemon=True
        )
        self._listen_thread.start()

    def stop(self) -> None:
        """Shut down TCP server."""
        if not self._running:
            return

        self._running = False
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
        logger.info("TCP Transfer Server stopped")

    def resolve_pending_request(self, transfer_id: str, accept: bool) -> bool:
        """Called by UI API when receiver clicks [ACCEPT] or [REJECT]."""
        with self._lock:
            pending = self._pending_decisions.get(transfer_id)
            if not pending:
                return False
            pending["accepted"] = accept
            pending["event"].set()
            return True

    def _accept_loop(self) -> None:
        """Accept incoming TCP client connections."""
        while self._running and self._server_sock:
            try:
                client_sock, client_addr = self._server_sock.accept()
                client_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                try:
                    client_sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 8 * 1024 * 1024)
                    client_sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
                except Exception:
                    pass
                handler = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, client_addr),
                    daemon=True,
                )
                handler.start()
            except (socket.error, OSError):
                break
            except Exception as e:
                logger.debug(f"Error accepting connection: {e}")

    def _handle_client(self, client_sock: socket.socket, client_addr: tuple) -> None:
        """Process an incoming file transfer session."""
        transfer_id = ""
        session: Optional[PartialTransferSession] = None
        start_time = time.time()
        transferred_bytes = 0
        total_bytes = 0
        file_name = "unknown"

        try:
            client_sock.settimeout(65.0)

            # Step 1: Read TRANSFER_REQUEST
            header, _ = decode_packet_from_socket(client_sock)
            if header.get("type") != MSG_TRANSFER_REQUEST:
                raise ProtocolError(f"Expected TRANSFER_REQUEST, got {header.get('type')}")

            transfer_id = header["transfer_id"]
            sender = header["sender"]
            file_name = sanitize_filename(header["item_name"])
            is_folder = bool(header.get("is_folder", False))
            total_bytes = int(header.get("total_bytes", 0))
            priority = header.get("priority", "MEDIUM")
            files_raw = header.get("files", [])
            files = [
                FileItem(relative_path=f["relative_path"], size=f["size"], sha256=f.get("sha256", ""))
                for f in files_raw
            ]

            # Auto-register sender in local discovery so receiver immediately sees them in peer list
            if self.discovery and sender.get("device_id"):
                from backend.models import Peer
                sender_peer = Peer(
                    device_id=sender["device_id"],
                    username=sender.get("username", "Unknown"),
                    hostname=sender.get("hostname", client_addr[0]),
                    ip=client_addr[0],
                    tcp_port=int(sender.get("tcp_port", self.config.transfer_port)),
                    last_seen=time.time(),
                    is_online=True,
                )
                self.discovery.register_peer(sender_peer)

            # Record initial PENDING transfer in database
            self.db.record_transfer({
                "id": transfer_id,
                "direction": "INCOMING",
                "peer_device_id": sender.get("device_id", "unknown"),
                "peer_username": sender.get("username", "Unknown"),
                "peer_hostname": sender.get("hostname", client_addr[0]),
                "peer_ip": client_addr[0],
                "file_name": file_name,
                "relative_path": header.get("relative_path", ""),
                "is_folder": 1 if is_folder else 0,
                "total_bytes": total_bytes,
                "transferred_bytes": 0,
                "sha256": header.get("sha256", ""),
                "status": "PENDING",
                "priority": priority,
                "error_message": "",
                "started_at": datetime.now().isoformat(),
                "completed_at": None,
                "duration_seconds": 0.0,
                "average_speed_mbps": 0.0,
                "retry_count": 0,
                "resumed": 0,
                "integrity_verified": 0,
            })

            # Check if this is an existing partial download to resume
            session = PartialTransferSession(
                transfer_id=transfer_id,
                partial_base_dir=self.config.partial_dir,
                download_base_dir=self.config.download_dir,
                item_name=file_name,
                is_folder=is_folder,
                files=files,
            )
            # Find resume offset for file 0
            initial_resume_offset = session.get_resume_offset(0)
            is_resumed = initial_resume_offset > 0

            # Step 2: Notify UI and wait for user's Accept/Reject click
            decision_event = threading.Event()
            decision_dict = {"event": decision_event, "accepted": False}
            with self._lock:
                self._pending_decisions[transfer_id] = decision_dict

            self.notifier.publish("INCOMING_TRANSFER_REQUEST", {
                "transfer_id": transfer_id,
                "sender": sender,
                "item_name": file_name,
                "is_folder": is_folder,
                "total_bytes": total_bytes,
                "file_count": len(files),
                "is_resumed": is_resumed,
                "resume_offset": initial_resume_offset,
            })

            logger.info(f"Waiting for user to accept/reject request {transfer_id} ({file_name})")
            decision_made = decision_event.wait(timeout=self.REQUEST_TIMEOUT_SEC)

            with self._lock:
                self._pending_decisions.pop(transfer_id, None)

            if not decision_made or not decision_dict["accepted"]:
                # User rejected or request timed out
                logger.info(f"Transfer request {transfer_id} rejected or timed out")
                resp = encode_packet({
                    "type": MSG_TRANSFER_RESPONSE,
                    "transfer_id": transfer_id,
                    "accepted": False,
                    "reason": "Rejected by user" if decision_made else "Request timed out",
                })
                client_sock.sendall(resp)
                self.db.record_transfer({
                    "id": transfer_id,
                    "direction": "INCOMING",
                    "peer_device_id": sender.get("device_id", "unknown"),
                    "peer_username": sender.get("username", "Unknown"),
                    "peer_hostname": sender.get("hostname", client_addr[0]),
                    "peer_ip": client_addr[0],
                    "file_name": file_name,
                    "relative_path": header.get("relative_path", ""),
                    "is_folder": 1 if is_folder else 0,
                    "total_bytes": total_bytes,
                    "transferred_bytes": 0,
                    "sha256": header.get("sha256", ""),
                    "status": "REJECTED",
                    "priority": priority,
                    "error_message": "Rejected by receiver",
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": 0.0,
                    "average_speed_mbps": 0.0,
                    "retry_count": 0,
                    "resumed": 0,
                    "integrity_verified": 0,
                })
                return

            resp = encode_packet({
                "type": MSG_TRANSFER_RESPONSE,
                "transfer_id": transfer_id,
                "accepted": True,
                "resume_offset": initial_resume_offset,
            })
            client_sock.sendall(resp)

            self.notifier.publish("TRANSFER_STARTED", {
                "transfer_id": transfer_id,
                "direction": "INCOMING",
                "item_name": file_name,
                "peer_username": sender.get("username", "Unknown"),
                "total_bytes": total_bytes,
                "priority": priority,
            })

            transferred_bytes = initial_resume_offset
            # Exclude user modal wait time by resetting timing right when data streaming begins
            stream_start_time = time.time()
            last_progress_emit = stream_start_time
            window_start_time = stream_start_time
            window_bytes = 0
            current_speed_mbps = 0.0

            receiver_ctx = {
                "sock": client_sock,
                "session": session,
                "priority": priority,
                "is_paused": False,
                "is_cancelled": False,
                "pause_event": threading.Event(),
                "transferred_bytes": transferred_bytes,
                "total_bytes": total_bytes,
                "file_name": file_name,
            }
            receiver_ctx["pause_event"].set()
            with self._lock:
                self._active_receivers[transfer_id] = receiver_ctx

            # Step 4: Receive CHUNKS
            while self._running:
                if receiver_ctx.get("is_cancelled"):
                    break

                while receiver_ctx.get("is_paused") and not receiver_ctx.get("is_cancelled"):
                    try:
                        rlist, _, _ = select.select([client_sock], [], [], 0.05)
                        if rlist:
                            in_pkt_hdr, _ = decode_packet_from_socket(client_sock)
                            in_pkt_type = in_pkt_hdr.get("type")
                            if in_pkt_type == MSG_TRANSFER_RESUME:
                                logger.info(f"Transfer {transfer_id} resumed by sender packet.")
                                receiver_ctx["is_paused"] = False
                                receiver_ctx["pause_event"].set()
                                self.db.update_transfer_status(transfer_id, "IN_PROGRESS")
                                self.notifier.publish("TRANSFER_RESUMED", {
                                    "transfer_id": transfer_id,
                                    "direction": "INCOMING",
                                })
                                break
                            elif in_pkt_type == MSG_TRANSFER_CANCEL:
                                logger.info(f"Transfer {transfer_id} cancelled by sender packet.")
                                receiver_ctx["is_cancelled"] = True
                                break
                    except Exception:
                        pass
                    receiver_ctx["pause_event"].wait(timeout=0.05)

                if receiver_ctx.get("is_cancelled"):
                    break

                chunk_header, chunk_payload = decode_packet_from_socket(client_sock)
                msg_type = chunk_header.get("type")

                if msg_type == MSG_TRANSFER_CANCEL:
                    logger.info(f"Transfer {transfer_id} cancelled by sender.")
                    receiver_ctx["is_cancelled"] = True
                    break

                if msg_type == MSG_TRANSFER_PAUSE:
                    logger.info(f"Transfer {transfer_id} paused by sender.")
                    receiver_ctx["is_paused"] = True
                    receiver_ctx["pause_event"].clear()
                    self.db.update_transfer_status(transfer_id, "PAUSED", transferred_bytes=transferred_bytes)
                    self.notifier.publish("TRANSFER_PAUSED", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                        "transferred_bytes": transferred_bytes,
                        "total_bytes": total_bytes,
                    })
                    continue

                if msg_type == MSG_TRANSFER_RESUME:
                    logger.info(f"Transfer {transfer_id} resumed by sender.")
                    receiver_ctx["is_paused"] = False
                    receiver_ctx["pause_event"].set()
                    self.db.update_transfer_status(transfer_id, "IN_PROGRESS")
                    self.notifier.publish("TRANSFER_RESUMED", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                    })
                    continue

                if msg_type == MSG_TRANSFER_COMPLETE:
                    # Sender signaled completion of all chunks
                    file_hashes = chunk_header.get("file_hashes")
                    if file_hashes:
                        session.update_expected_hashes(file_hashes)
                    final_sha256 = chunk_header.get("sha256") or header.get("sha256", "")
                    break

                if msg_type != MSG_CHUNK:
                    raise ProtocolError(f"Unexpected packet type during stream: {msg_type}")

                file_idx = chunk_header["file_index"]
                chunk_idx = chunk_header["chunk_index"]
                offset = chunk_header["offset"]
                expected_chunk_hash = chunk_header.get("chunk_sha256")

                # Verify individual chunk integrity
                if expected_chunk_hash:
                    actual_chunk_hash = hashlib.sha256(chunk_payload).hexdigest()
                    if actual_chunk_hash.lower() != expected_chunk_hash.lower():
                        logger.warning(f"Corrupted chunk {chunk_idx} received on {transfer_id}")
                        ack = encode_packet({
                            "type": MSG_CHUNK_ACK,
                            "transfer_id": transfer_id,
                            "file_index": file_idx,
                            "chunk_index": chunk_idx,
                            "status": "CORRUPT",
                        })
                        client_sock.sendall(ack)
                        continue

                # Send ACK immediately so sender begins transmitting next chunk while we write to disk
                ack_status = "PAUSED" if receiver_ctx.get("is_paused") else "OK"
                ack = encode_packet({
                    "type": MSG_CHUNK_ACK,
                    "transfer_id": transfer_id,
                    "file_index": file_idx,
                    "chunk_index": chunk_idx,
                    "status": ack_status,
                    "offset": offset,
                })
                client_sock.sendall(ack)

                # Write chunk to session part file
                session.write_chunk(file_idx, offset, chunk_payload)
                transferred_bytes += len(chunk_payload)
                receiver_ctx["transferred_bytes"] = transferred_bytes
                window_bytes += len(chunk_payload)

                # Throttle progress notifications to ~10 updates/second max for silky UI
                now = time.time()
                if now - last_progress_emit >= 0.1:
                    win_elapsed = now - window_start_time
                    if win_elapsed >= 0.5:
                        current_speed_mbps = (window_bytes / (1024 * 1024)) / win_elapsed
                        window_bytes = 0
                        window_start_time = now

                    overall_duration = max(now - stream_start_time, 0.001)
                    display_speed = current_speed_mbps if current_speed_mbps > 0 else (transferred_bytes / (1024 * 1024)) / overall_duration
                    remaining_bytes = max(total_bytes - transferred_bytes, 0)
                    speed_bytes_sec = display_speed * 1024 * 1024
                    eta_sec = int(remaining_bytes / speed_bytes_sec) if speed_bytes_sec > 0 else 0
                    percent = round((transferred_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 100.0

                    self.notifier.publish("TRANSFER_PROGRESS", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                        "transferred_bytes": transferred_bytes,
                        "total_bytes": total_bytes,
                        "percent": percent,
                        "speed_mbps": round(display_speed, 2),
                        "eta_seconds": eta_sec,
                        "chunk_size_kb": len(chunk_payload) // 1024,
                    })
                    last_progress_emit = now

            if receiver_ctx.get("is_cancelled"):
                duration = max(time.time() - stream_start_time, 0.001)
                self.db.record_transfer({
                    "id": transfer_id,
                    "direction": "INCOMING",
                    "peer_device_id": sender.get("device_id", "unknown"),
                    "peer_username": sender.get("username", "Unknown"),
                    "peer_hostname": sender.get("hostname", client_addr[0]),
                    "peer_ip": client_addr[0],
                    "file_name": file_name,
                    "relative_path": header.get("relative_path", ""),
                    "is_folder": 1 if is_folder else 0,
                    "total_bytes": total_bytes,
                    "transferred_bytes": transferred_bytes,
                    "sha256": header.get("sha256", ""),
                    "status": "CANCELLED",
                    "priority": priority,
                    "error_message": "Transfer cancelled by user",
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": round(duration, 2),
                    "average_speed_mbps": 0.0,
                    "retry_count": 0,
                    "resumed": 1 if is_resumed else 0,
                    "integrity_verified": 0,
                })
                self.notifier.publish("TRANSFER_CANCELLED", {
                    "transfer_id": transfer_id,
                    "direction": "INCOMING",
                    "error": "Transfer cancelled by user",
                })
                return

            # Step 5: Finalize and verify SHA-256
            success, msg = session.finalize_and_verify()
            duration = max(time.time() - stream_start_time, 0.001)
            avg_speed = round((transferred_bytes / (1024 * 1024)) / duration, 2)

            if success:
                logger.info(f"Transfer {transfer_id} completed successfully. Verified and saved.")
                final_pkt = encode_packet({
                    "type": MSG_TRANSFER_COMPLETE,
                    "transfer_id": transfer_id,
                    "verified": True,
                    "message": "File verified and saved successfully",
                })
                client_sock.sendall(final_pkt)

                self.db.record_transfer({
                    "id": transfer_id,
                    "direction": "INCOMING",
                    "peer_device_id": sender.get("device_id", "unknown"),
                    "peer_username": sender.get("username", "Unknown"),
                    "peer_hostname": sender.get("hostname", client_addr[0]),
                    "peer_ip": client_addr[0],
                    "file_name": file_name,
                    "relative_path": header.get("relative_path", ""),
                    "is_folder": 1 if is_folder else 0,
                    "total_bytes": total_bytes,
                    "transferred_bytes": total_bytes,
                    "sha256": final_sha256 if "final_sha256" in locals() else header.get("sha256", ""),
                    "status": "COMPLETED",
                    "priority": priority,
                    "error_message": "",
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": round(duration, 2),
                    "average_speed_mbps": avg_speed,
                    "retry_count": 0,
                    "resumed": 1 if is_resumed else 0,
                    "integrity_verified": 1,
                })

                self.notifier.publish("TRANSFER_COMPLETED", {
                    "transfer_id": transfer_id,
                    "direction": "INCOMING",
                    "file_name": file_name,
                    "verified": True,
                    "download_dir": str(self.config.download_dir),
                })

            else:
                logger.error(f"Transfer {transfer_id} integrity verification failed: {msg}")
                final_pkt = encode_packet({
                    "type": MSG_TRANSFER_FAILED,
                    "transfer_id": transfer_id,
                    "reason": msg,
                })
                client_sock.sendall(final_pkt)

                self.db.record_transfer({
                    "id": transfer_id,
                    "direction": "INCOMING",
                    "peer_device_id": sender.get("device_id", "unknown"),
                    "peer_username": sender.get("username", "Unknown"),
                    "peer_hostname": sender.get("hostname", client_addr[0]),
                    "peer_ip": client_addr[0],
                    "file_name": file_name,
                    "relative_path": header.get("relative_path", ""),
                    "is_folder": 1 if is_folder else 0,
                    "total_bytes": total_bytes,
                    "transferred_bytes": transferred_bytes,
                    "sha256": header.get("sha256", ""),
                    "status": "FAILED",
                    "priority": priority,
                    "error_message": msg,
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": round(duration, 2),
                    "average_speed_mbps": avg_speed,
                    "retry_count": 0,
                    "resumed": 1 if is_resumed else 0,
                    "integrity_verified": 0,
                })

                self.notifier.publish("TRANSFER_FAILED", {
                    "transfer_id": transfer_id,
                    "direction": "INCOMING",
                    "error": msg,
                })

        except Exception as e:
            if transfer_id:
                is_canc = receiver_ctx.get("is_cancelled") if "receiver_ctx" in locals() else False
                is_pau = receiver_ctx.get("is_paused") if "receiver_ctx" in locals() else False

                if is_canc:
                    status = "CANCELLED"
                    err_msg = "Transfer cancelled by user"
                elif is_pau:
                    status = "PAUSED"
                    err_msg = "Transfer paused"
                else:
                    logger.error(f"Error handling transfer client {transfer_id}: {e}")
                    status = "FAILED"
                    err_msg = str(e)

                self.db.record_transfer({
                    "id": transfer_id,
                    "direction": "INCOMING",
                    "peer_device_id": sender.get("device_id", "unknown") if "sender" in locals() else "unknown",
                    "peer_username": sender.get("username", "Unknown") if "sender" in locals() else "Unknown",
                    "peer_hostname": sender.get("hostname", client_addr[0]) if "sender" in locals() else client_addr[0],
                    "peer_ip": client_addr[0],
                    "file_name": file_name,
                    "relative_path": "",
                    "is_folder": 0,
                    "total_bytes": total_bytes,
                    "transferred_bytes": transferred_bytes,
                    "sha256": "",
                    "status": status,
                    "priority": "MEDIUM",
                    "error_message": err_msg,
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat() if status != "PAUSED" else None,
                    "duration_seconds": round(time.time() - (stream_start_time if 'stream_start_time' in locals() else start_time), 2),
                    "average_speed_mbps": 0.0,
                    "retry_count": 0,
                    "resumed": 1 if is_resumed else 0,
                    "integrity_verified": 0,
                })
                if status == "CANCELLED":
                    self.notifier.publish("TRANSFER_CANCELLED", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                        "error": err_msg,
                    })
                elif status == "PAUSED":
                    self.notifier.publish("TRANSFER_PAUSED", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                        "transferred_bytes": transferred_bytes,
                        "total_bytes": total_bytes,
                    })
                else:
                    self.notifier.publish("TRANSFER_FAILED", {
                        "transfer_id": transfer_id,
                        "direction": "INCOMING",
                        "error": str(e),
                    })
        finally:
            if transfer_id:
                with self._lock:
                    self._active_receivers.pop(transfer_id, None)
            if session:
                try:
                    session.close()
                except Exception:
                    pass
            try:
                client_sock.close()
            except Exception:
                pass
