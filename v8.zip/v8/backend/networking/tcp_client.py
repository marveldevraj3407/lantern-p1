"""TCP client for initiating file and folder transfers to peer PCs."""

from __future__ import annotations

from datetime import datetime
import hashlib
import logging
from pathlib import Path
import select
import socket
import threading
import time
from typing import Any, Dict, List, Optional

from backend.config import AppConfig
from backend.database import Database
from backend.models import FileItem, Peer
from backend.networking.protocol import (
    decode_packet_from_socket,
    encode_packet,
    MSG_CHUNK,
    MSG_CHUNK_ACK,
    MSG_TRANSFER_CANCEL,
    MSG_TRANSFER_COMPLETE,
    MSG_TRANSFER_PAUSE,
    MSG_TRANSFER_REQUEST,
    MSG_TRANSFER_RESPONSE,
    MSG_TRANSFER_RESUME,
    ProtocolError,
)
from backend.services.notification_service import NotificationBus
from backend.transfer.adaptive import AdaptiveEngine
from backend.transfer.bandwidth import BandwidthController
from backend.transfer.chunking import stream_file_chunks

logger = logging.getLogger("TCPClient")


class TransferSender:
    """Handles an outgoing transfer session to a single recipient."""

    def __init__(
        self,
        config: AppConfig,
        database: Database,
        notifier: NotificationBus,
        bandwidth_ctrl: BandwidthController,
        transfer_id: str,
        peer: Peer,
        source_path: Path | str,
        item_name: str,
        is_folder: bool,
        files: List[FileItem],
        total_bytes: int,
        priority: str = "MEDIUM",
        is_adaptive: bool = True,
    ) -> None:
        self.config = config
        self.db = database
        self.notifier = notifier
        self.bandwidth_ctrl = bandwidth_ctrl

        self.transfer_id = transfer_id
        self.peer = peer
        self.source_path = Path(source_path)
        self.item_name = item_name
        self.is_folder = is_folder
        self.files = files
        self.total_bytes = total_bytes
        self.priority = priority.upper()
        self.is_adaptive = is_adaptive

        self.adaptive_engine = AdaptiveEngine(transfer_id, is_adaptive=is_adaptive)
        self.transferred_bytes = 0
        self.is_paused = False
        self.is_cancelled = False
        self._pause_event = threading.Event()
        self._pause_event.set()
        self._sock: Optional[socket.socket] = None

    def pause(self) -> bool:
        if self.is_cancelled:
            return False
        self.is_paused = True
        self._pause_event.clear()
        try:
            if self._sock:
                pause_pkt = encode_packet({"type": MSG_TRANSFER_PAUSE, "transfer_id": self.transfer_id})
                self._sock.sendall(pause_pkt)
        except Exception:
            pass
        self.db.update_transfer_status(self.transfer_id, "PAUSED", transferred_bytes=self.transferred_bytes)
        self.notifier.publish("TRANSFER_PAUSED", {
            "transfer_id": self.transfer_id,
            "direction": "OUTGOING",
            "transferred_bytes": self.transferred_bytes,
            "total_bytes": self.total_bytes,
        })
        return True

    def resume(self) -> bool:
        if self.is_cancelled:
            return False
        self.is_paused = False
        self._pause_event.set()
        try:
            if self._sock:
                resume_pkt = encode_packet({"type": MSG_TRANSFER_RESUME, "transfer_id": self.transfer_id})
                self._sock.sendall(resume_pkt)
        except Exception:
            pass
        self.db.update_transfer_status(self.transfer_id, "IN_PROGRESS")
        self.notifier.publish("TRANSFER_RESUMED", {
            "transfer_id": self.transfer_id,
            "direction": "OUTGOING",
        })
        return True

    def cancel(self) -> bool:
        self.is_cancelled = True
        self._pause_event.set()
        try:
            if self._sock:
                cancel_pkt = encode_packet({"type": MSG_TRANSFER_CANCEL, "transfer_id": self.transfer_id})
                self._sock.sendall(cancel_pkt)
                self._sock.close()
        except Exception:
            pass
        self.db.update_transfer_status(self.transfer_id, "CANCELLED", "Transfer cancelled by user")
        self.notifier.publish("TRANSFER_CANCELLED", {
            "transfer_id": self.transfer_id,
            "direction": "OUTGOING",
            "error": "Transfer cancelled by user",
        })
        return True

    def set_priority(self, new_priority: str) -> bool:
        """Dynamically update priority mid-transfer (Free Download Manager style)."""
        norm = new_priority.upper()
        if norm not in ("HIGH", "MEDIUM", "LOW"):
            return False
        self.priority = norm
        self.bandwidth_ctrl.update_priority(self.transfer_id, norm)
        try:
            self.db.update_transfer_priority(self.transfer_id, norm)
        except Exception as exc:
            logger.warning(f"Failed to update transfer priority in db: {exc}")
        self.notifier.publish("TRANSFER_PRIORITY_UPDATED", {
            "transfer_id": self.transfer_id,
            "direction": "OUTGOING",
            "priority": norm,
        })
        return True

    def run(self) -> bool:
        """Execute the transfer session. Returns True on success, False on error/reject."""
        sock: Optional[socket.socket] = None
        self._sock = None
        start_time = time.time()
        self.transferred_bytes = 0
        overall_sha256 = self.files[0].sha256 if (not self.is_folder and self.files) else ""

        # Record initial PENDING transfer in database
        self.db.record_transfer({
            "id": self.transfer_id,
            "direction": "OUTGOING",
            "peer_device_id": self.peer.device_id,
            "peer_username": self.peer.username,
            "peer_hostname": self.peer.hostname,
            "peer_ip": self.peer.ip,
            "file_name": self.item_name,
            "relative_path": "",
            "is_folder": 1 if self.is_folder else 0,
            "total_bytes": self.total_bytes,
            "transferred_bytes": 0,
            "sha256": overall_sha256,
            "status": "PENDING",
            "priority": self.priority,
            "error_message": "",
            "started_at": datetime.now().isoformat(),
            "completed_at": None,
            "duration_seconds": 0.0,
            "average_speed_mbps": 0.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 0,
        })

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock = sock
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 8 * 1024 * 1024)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
            except Exception:
                pass
            sock.settimeout(15.0)
            logger.info(f"Connecting to {self.peer.username} ({self.peer.ip}:{self.peer.tcp_port})")
            sock.connect((self.peer.ip, self.peer.tcp_port))

            # Step 1: Send TRANSFER_REQUEST
            req_packet = encode_packet({
                "type": MSG_TRANSFER_REQUEST,
                "transfer_id": self.transfer_id,
                "sender": {
                    "device_id": self.config.device_id,
                    "username": self.config.username,
                    "hostname": self.config.hostname,
                    "ip": self.config.local_ip,
                    "tcp_port": self.config.transfer_port,
                },
                "item_name": self.item_name,
                "is_folder": self.is_folder,
                "total_bytes": self.total_bytes,
                "priority": self.priority,
                "sha256": overall_sha256,
                "files": [
                    {"relative_path": f.relative_path, "size": f.size, "sha256": f.sha256}
                    for f in self.files
                ],
            })
            sock.sendall(req_packet)

            # Step 2: Wait for TRANSFER_RESPONSE (Accept or Reject)
            sock.settimeout(65.0)
            resp_header, _ = decode_packet_from_socket(sock)
            if resp_header.get("type") != MSG_TRANSFER_RESPONSE:
                raise ProtocolError(f"Expected TRANSFER_RESPONSE, got {resp_header.get('type')}")

            if not resp_header.get("accepted"):
                reason = resp_header.get("reason", "Rejected by recipient")
                logger.info(f"Transfer {self.transfer_id} rejected: {reason}")
                self.db.record_transfer({
                    "id": self.transfer_id,
                    "direction": "OUTGOING",
                    "peer_device_id": self.peer.device_id,
                    "peer_username": self.peer.username,
                    "peer_hostname": self.peer.hostname,
                    "peer_ip": self.peer.ip,
                    "file_name": self.item_name,
                    "relative_path": "",
                    "is_folder": 1 if self.is_folder else 0,
                    "total_bytes": self.total_bytes,
                    "transferred_bytes": 0,
                    "sha256": overall_sha256,
                    "status": "REJECTED",
                    "priority": self.priority,
                    "error_message": reason,
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": 0.0,
                    "average_speed_mbps": 0.0,
                    "retry_count": 0,
                    "resumed": 0,
                    "integrity_verified": 0,
                })
                self.notifier.publish("TRANSFER_REJECTED", {
                    "transfer_id": self.transfer_id,
                    "peer_username": self.peer.username,
                    "reason": reason,
                })
                return False

            resume_offset = resp_header.get("resume_offset", 0)
            is_resumed = resume_offset > 0
            self.transferred_bytes = resume_offset
            transferred_bytes = resume_offset

            self.bandwidth_ctrl.register_transfer(self.transfer_id, self.priority)
            self.notifier.publish("TRANSFER_STARTED", {
                "transfer_id": self.transfer_id,
                "direction": "OUTGOING",
                "item_name": self.item_name,
                "peer_username": self.peer.username,
                "total_bytes": self.total_bytes,
                "priority": self.priority,
                "is_resumed": is_resumed,
            })

            # Exclude user modal wait time by resetting timing right when data streaming begins
            self.adaptive_engine.start_streaming()
            stream_start_time = time.time()
            last_progress_emit = stream_start_time
            window_start_time = stream_start_time
            window_bytes = 0
            current_speed_mbps = 0.0

            sock.settimeout(30.0)

            # Step 3: Stream chunks of each file
            computed_file_hashes: Dict[int, str] = {}
            for file_idx, file_item in enumerate(self.files):
                if self.is_cancelled:
                    break

                # Resolve physical source path directly from original location
                if self.is_folder:
                    file_phys_path = self.source_path / file_item.relative_path
                else:
                    file_phys_path = self.source_path

                file_offset = resume_offset if file_idx == 0 else 0
                file_hasher = hashlib.sha256()

                # If resuming from non-zero offset, hash initial portion
                if file_offset > 0:
                    with open(file_phys_path, "rb", buffering=4 * 1024 * 1024) as f_init:
                        bytes_to_hash = file_offset
                        while bytes_to_hash > 0:
                            chunk = f_init.read(min(bytes_to_hash, 4 * 1024 * 1024))
                            if not chunk:
                                break
                            file_hasher.update(chunk)
                            bytes_to_hash -= len(chunk)

                # Open physical file ONCE with a 4MB buffer instead of reopening per chunk
                with open(file_phys_path, "rb", buffering=4 * 1024 * 1024) as f:
                    if file_offset > 0:
                        f.seek(file_offset)

                    while file_offset < file_item.size:
                        if self.is_cancelled:
                            break

                        while self.is_paused and not self.is_cancelled:
                            self._pause_event.wait(timeout=0.2)
                            if self.is_paused and not self.is_cancelled and sock:
                                try:
                                    rlist, _, _ = select.select([sock], [], [], 0.05)
                                    if rlist:
                                        in_hdr, _ = decode_packet_from_socket(sock)
                                        in_type = in_hdr.get("type")
                                        if in_type == MSG_TRANSFER_RESUME or in_hdr.get("status") == "RESUMED":
                                            logger.info(f"Transfer {self.transfer_id} resumed by recipient packet")
                                            self.resume()
                                            break
                                        elif in_type == MSG_TRANSFER_CANCEL or in_hdr.get("status") == "CANCELLED":
                                            logger.info(f"Transfer {self.transfer_id} cancelled by recipient packet")
                                            self.cancel()
                                            break
                                except Exception:
                                    pass

                        if self.is_cancelled:
                            break

                        # Query adaptive engine for optimal chunk size
                        chunk_size = self.adaptive_engine.get_next_chunk_size()
                        chunk_size = min(chunk_size, file_item.size - file_offset)

                        # Read chunk directly from the open file stream
                        chunk_data = f.read(chunk_size)
                        if not chunk_data:
                            break

                        file_hasher.update(chunk_data)
                        chunk_index = file_offset // max(chunk_size, 1)

                        # Frame CHUNK packet
                        chunk_header = {
                            "type": MSG_CHUNK,
                            "transfer_id": self.transfer_id,
                            "file_index": file_idx,
                            "chunk_index": chunk_index,
                            "offset": file_offset,
                        }
                        packet_bytes = encode_packet(chunk_header, chunk_data)

                        # Pacing via bandwidth controller
                        self.bandwidth_ctrl.pace_chunk(self.transfer_id, len(chunk_data))

                        # Send and measure RTT
                        t_send = time.perf_counter()
                        sock.sendall(packet_bytes)

                        # Wait for CHUNK_ACK
                        ack_header, _ = decode_packet_from_socket(sock)
                        rtt_ms = (time.perf_counter() - t_send) * 1000.0

                        ack_type = ack_header.get("type")
                        ack_status = ack_header.get("status")

                        if ack_type == MSG_TRANSFER_CANCEL or ack_status == "CANCELLED":
                            logger.info(f"Transfer {self.transfer_id} cancelled by recipient ACK")
                            self.is_cancelled = True
                            break

                        if ack_type == MSG_TRANSFER_PAUSE or ack_status == "PAUSED":
                            logger.info(f"Transfer {self.transfer_id} paused by recipient")
                            self.is_paused = True
                            self._pause_event.clear()
                            self.db.update_transfer_status(self.transfer_id, "PAUSED", transferred_bytes=self.transferred_bytes)
                            self.notifier.publish("TRANSFER_PAUSED", {
                                "transfer_id": self.transfer_id,
                                "direction": "OUTGOING",
                                "transferred_bytes": self.transferred_bytes,
                                "total_bytes": self.total_bytes,
                            })
                            while self.is_paused and not self.is_cancelled:
                                self._pause_event.wait(timeout=0.2)
                                if self.is_paused and not self.is_cancelled and sock:
                                    try:
                                        rlist, _, _ = select.select([sock], [], [], 0.05)
                                        if rlist:
                                            in_hdr, _ = decode_packet_from_socket(sock)
                                            in_type = in_hdr.get("type")
                                            if in_type == MSG_TRANSFER_RESUME or in_hdr.get("status") == "RESUMED":
                                                logger.info(f"Transfer {self.transfer_id} resumed by recipient packet")
                                                self.resume()
                                                break
                                            elif in_type == MSG_TRANSFER_CANCEL or in_hdr.get("status") == "CANCELLED":
                                                logger.info(f"Transfer {self.transfer_id} cancelled by recipient packet")
                                                self.cancel()
                                                break
                                    except Exception:
                                        pass
                            if self.is_cancelled:
                                break
                            continue

                        if ack_header.get("type") != MSG_CHUNK_ACK or ack_header.get("status") != "OK":
                            logger.warning(f"Bad ACK on chunk {chunk_index}, will retry")
                            self.adaptive_engine.record_chunk_ack(
                                len(chunk_data), rtt_ms, success=False,
                                concurrency=self.bandwidth_ctrl.get_active_count(),
                            )
                            # Reposition file stream to re-read failed chunk
                            f.seek(file_offset)
                            continue

                        # Successful chunk!
                        self.adaptive_engine.record_chunk_ack(
                            len(chunk_data), rtt_ms, success=True,
                            concurrency=self.bandwidth_ctrl.get_active_count(),
                        )
                        file_offset += len(chunk_data)
                        self.transferred_bytes += len(chunk_data)
                        transferred_bytes = self.transferred_bytes
                        window_bytes += len(chunk_data)

                        # Emit progress
                        now = time.time()
                        if now - last_progress_emit >= 0.1:
                            win_elapsed = now - window_start_time
                            if win_elapsed >= 0.5:
                                current_speed_mbps = (window_bytes / (1024 * 1024)) / win_elapsed
                                window_bytes = 0
                                window_start_time = now

                            overall_duration = max(now - stream_start_time, 0.001)
                            display_speed = current_speed_mbps if current_speed_mbps > 0 else (transferred_bytes / (1024 * 1024)) / overall_duration
                            rem_bytes = max(self.total_bytes - transferred_bytes, 0)
                            speed_bytes_sec = display_speed * 1024 * 1024
                            eta_sec = int(rem_bytes / speed_bytes_sec) if speed_bytes_sec > 0 else 0
                            percent = round((transferred_bytes / self.total_bytes) * 100, 1) if self.total_bytes > 0 else 100.0

                            self.notifier.publish("TRANSFER_PROGRESS", {
                                "transfer_id": self.transfer_id,
                                "direction": "OUTGOING",
                                "transferred_bytes": transferred_bytes,
                                "total_bytes": self.total_bytes,
                                "percent": percent,
                                "speed_mbps": round(display_speed, 2),
                                "eta_seconds": eta_sec,
                                "chunk_size_kb": chunk_size // 1024,
                            })
                            last_progress_emit = now

                computed_file_hashes[file_idx] = file_item.sha256 or file_hasher.hexdigest()

            if self.is_cancelled:
                duration = max(time.time() - stream_start_time, 0.001)
                self.db.record_transfer({
                    "id": self.transfer_id,
                    "direction": "OUTGOING",
                    "peer_device_id": self.peer.device_id,
                    "peer_username": self.peer.username,
                    "peer_hostname": self.peer.hostname,
                    "peer_ip": self.peer.ip,
                    "file_name": self.item_name,
                    "relative_path": "",
                    "is_folder": 1 if self.is_folder else 0,
                    "total_bytes": self.total_bytes,
                    "transferred_bytes": self.transferred_bytes,
                    "sha256": overall_sha256,
                    "status": "CANCELLED",
                    "priority": self.priority,
                    "error_message": "Transfer cancelled by user",
                    "started_at": datetime.now().isoformat(),
                    "completed_at": datetime.now().isoformat(),
                    "duration_seconds": round(duration, 2),
                    "average_speed_mbps": 0.0,
                    "retry_count": self.adaptive_engine.retry_count,
                    "resumed": 1 if is_resumed else 0,
                    "integrity_verified": 0,
                })
                self.notifier.publish("TRANSFER_CANCELLED", {
                    "transfer_id": self.transfer_id,
                    "direction": "OUTGOING",
                    "error": "Transfer cancelled by user",
                })
                return False

            # Step 4: Signal TRANSFER_COMPLETE and read verification
            overall_sha256 = computed_file_hashes.get(0, "") if not self.is_folder else ""
            complete_pkt = encode_packet({
                "type": MSG_TRANSFER_COMPLETE,
                "transfer_id": self.transfer_id,
                "sha256": overall_sha256,
                "file_hashes": computed_file_hashes,
            })
            sock.sendall(complete_pkt)

            final_header, _ = decode_packet_from_socket(sock)
            duration = max(time.time() - stream_start_time, 0.001)
            avg_speed = round((transferred_bytes / (1024 * 1024)) / duration, 2)
            verified = bool(final_header.get("verified", False))

            # Store research metrics
            metrics = self.adaptive_engine.generate_research_metrics(self.total_bytes)
            self.db.record_research_metric(metrics)

            self.db.record_transfer({
                "id": self.transfer_id,
                "direction": "OUTGOING",
                "peer_device_id": self.peer.device_id,
                "peer_username": self.peer.username,
                "peer_hostname": self.peer.hostname,
                "peer_ip": self.peer.ip,
                "file_name": self.item_name,
                "relative_path": "",
                "is_folder": 1 if self.is_folder else 0,
                "total_bytes": self.total_bytes,
                "transferred_bytes": self.total_bytes,
                "sha256": overall_sha256,
                "status": "COMPLETED" if verified else "FAILED",
                "priority": self.priority,
                "error_message": "" if verified else "Receiver verification failed",
                "started_at": datetime.now().isoformat(),
                "completed_at": datetime.now().isoformat(),
                "duration_seconds": round(duration, 2),
                "average_speed_mbps": avg_speed,
                "retry_count": self.adaptive_engine.retry_count,
                "resumed": 1 if is_resumed else 0,
                "integrity_verified": 1 if verified else 0,
            })

            self.notifier.publish("TRANSFER_COMPLETED", {
                "transfer_id": self.transfer_id,
                "direction": "OUTGOING",
                "file_name": self.item_name,
                "peer_username": self.peer.username,
                "verified": verified,
            })
            return verified

        except Exception as e:
            duration = max(time.time() - (stream_start_time if 'stream_start_time' in locals() else start_time), 0.001)
            if self.is_cancelled:
                status = "CANCELLED"
                err_msg = "Transfer cancelled by user"
            elif self.is_paused:
                status = "PAUSED"
                err_msg = "Transfer paused"
            else:
                logger.error(f"Transfer error on {self.transfer_id}: {e}")
                status = "FAILED"
                err_msg = str(e)

            self.db.record_transfer({
                "id": self.transfer_id,
                "direction": "OUTGOING",
                "peer_device_id": self.peer.device_id,
                "peer_username": self.peer.username,
                "peer_hostname": self.peer.hostname,
                "peer_ip": self.peer.ip,
                "file_name": self.item_name,
                "relative_path": "",
                "is_folder": 1 if self.is_folder else 0,
                "total_bytes": self.total_bytes,
                "transferred_bytes": self.transferred_bytes,
                "sha256": overall_sha256,
                "status": status,
                "priority": self.priority,
                "error_message": err_msg,
                "started_at": datetime.now().isoformat(),
                "completed_at": datetime.now().isoformat() if status != "PAUSED" else None,
                "duration_seconds": round(duration, 2),
                "average_speed_mbps": 0.0,
                "retry_count": self.adaptive_engine.retry_count,
                "resumed": 1 if is_resumed else 0,
                "integrity_verified": 0,
            })
            if status == "CANCELLED":
                self.notifier.publish("TRANSFER_CANCELLED", {
                    "transfer_id": self.transfer_id,
                    "direction": "OUTGOING",
                    "error": err_msg,
                })
            elif status == "PAUSED":
                self.notifier.publish("TRANSFER_PAUSED", {
                    "transfer_id": self.transfer_id,
                    "direction": "OUTGOING",
                    "transferred_bytes": self.transferred_bytes,
                    "total_bytes": self.total_bytes,
                })
            else:
                self.notifier.publish("TRANSFER_FAILED", {
                    "transfer_id": self.transfer_id,
                    "direction": "OUTGOING",
                    "error": str(e),
                })
            return False

        finally:
            self.bandwidth_ctrl.unregister_transfer(self.transfer_id)
            if sock:
                try:
                    sock.close()
                except Exception:
                    pass
