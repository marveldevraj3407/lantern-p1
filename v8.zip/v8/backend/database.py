"""Database schema and persistence for metadata, transfers, and research metrics.

CRITICAL RULE:
Transfer history stores METADATA ONLY.
File contents/blobs MUST NEVER be stored in the database.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import sqlite3
from typing import Any, Dict, List, Optional


class Database:
    """Encapsulates SQLite interactions for transfers and research records."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self) -> None:
        """Create necessary tables if they do not exist."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()

            # Transfers table (historical record of all incoming & outgoing transfers)
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS transfers (
                    id TEXT PRIMARY KEY,
                    direction TEXT NOT NULL,          -- 'INCOMING' or 'OUTGOING'
                    peer_device_id TEXT NOT NULL,
                    peer_username TEXT NOT NULL,
                    peer_hostname TEXT NOT NULL,
                    peer_ip TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    relative_path TEXT NOT NULL DEFAULT '', -- For folder transfers
                    is_folder INTEGER NOT NULL DEFAULT 0,
                    total_bytes INTEGER NOT NULL,
                    transferred_bytes INTEGER NOT NULL DEFAULT 0,
                    sha256 TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL,             -- 'PENDING', 'ACCEPTED', 'REJECTED', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'PAUSED'
                    priority TEXT NOT NULL DEFAULT 'MEDIUM',
                    error_message TEXT NOT NULL DEFAULT '',
                    started_at TEXT NOT NULL,
                    completed_at TEXT DEFAULT NULL,
                    duration_seconds REAL DEFAULT 0.0,
                    average_speed_mbps REAL DEFAULT 0.0,
                    retry_count INTEGER NOT NULL DEFAULT 0,
                    resumed INTEGER NOT NULL DEFAULT 0,
                    integrity_verified INTEGER NOT NULL DEFAULT 0
                )
                """
            )

            # Research metrics table (evaluates dynamic chunking vs baseline fixed chunking)
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS research_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    transfer_id TEXT NOT NULL,
                    mode TEXT NOT NULL,               -- 'ADAPTIVE' or 'BASELINE_FIXED'
                    file_size INTEGER NOT NULL,
                    total_time_seconds REAL NOT NULL,
                    avg_throughput_mbps REAL NOT NULL,
                    peak_throughput_mbps REAL NOT NULL,
                    chunk_size_min INTEGER NOT NULL,
                    chunk_size_max INTEGER NOT NULL,
                    chunk_size_final INTEGER NOT NULL,
                    total_chunks INTEGER NOT NULL,
                    retry_count INTEGER NOT NULL,
                    retransmitted_bytes INTEGER NOT NULL,
                    rtt_avg_ms REAL NOT NULL,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (transfer_id) REFERENCES transfers (id)
                )
                """
            )

            # Indices for quick search & filtering
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_transfers_status ON transfers(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_transfers_file ON transfers(file_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_transfers_date ON transfers(started_at)")
            conn.commit()
        finally:
            conn.close()

    def record_transfer(self, record: Dict[str, Any]) -> None:
        """Insert or replace a transfer record."""
        sql = """
            INSERT INTO transfers (
                id, direction, peer_device_id, peer_username, peer_hostname,
                peer_ip, file_name, relative_path, is_folder, total_bytes,
                transferred_bytes, sha256, status, priority, error_message,
                started_at, completed_at, duration_seconds, average_speed_mbps,
                retry_count, resumed, integrity_verified
            ) VALUES (
                :id, :direction, :peer_device_id, :peer_username, :peer_hostname,
                :peer_ip, :file_name, :relative_path, :is_folder, :total_bytes,
                :transferred_bytes, :sha256, :status, :priority, :error_message,
                :started_at, :completed_at, :duration_seconds, :average_speed_mbps,
                :retry_count, :resumed, :integrity_verified
            )
            ON CONFLICT(id) DO UPDATE SET
                transferred_bytes = excluded.transferred_bytes,
                status = excluded.status,
                error_message = excluded.error_message,
                completed_at = excluded.completed_at,
                duration_seconds = excluded.duration_seconds,
                average_speed_mbps = excluded.average_speed_mbps,
                retry_count = excluded.retry_count,
                resumed = excluded.resumed,
                integrity_verified = excluded.integrity_verified,
                priority = CASE WHEN excluded.priority != '' THEN excluded.priority ELSE transfers.priority END,
                sha256 = CASE WHEN excluded.sha256 != '' THEN excluded.sha256 ELSE transfers.sha256 END
        """
        conn = self._get_connection()
        try:
            conn.execute(sql, record)
            conn.commit()
        finally:
            conn.close()

    def get_transfer(self, transfer_id: str) -> Optional[Dict[str, Any]]:
        """Fetch transfer by ID."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM transfers WHERE id = ?", (transfer_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def update_transfer_priority(self, transfer_id: str, priority: str) -> None:
        """Update transfer priority (HIGH, MEDIUM, LOW)."""
        conn = self._get_connection()
        try:
            conn.execute(
                "UPDATE transfers SET priority = ? WHERE id = ?",
                (priority.upper(), transfer_id),
            )
            conn.commit()
        finally:
            conn.close()

    def update_transfer_status(
        self,
        transfer_id: str,
        status: str,
        error_message: str = "",
        transferred_bytes: Optional[int] = None,
    ) -> None:
        """Update transfer status and optional error message or progress."""
        conn = self._get_connection()
        try:
            if transferred_bytes is not None:
                conn.execute(
                    """
                    UPDATE transfers
                    SET status = ?,
                        error_message = CASE WHEN ? != '' THEN ? ELSE error_message END,
                        transferred_bytes = ?
                    WHERE id = ?
                    """,
                    (status, error_message, error_message, transferred_bytes, transfer_id),
                )
            else:
                conn.execute(
                    """
                    UPDATE transfers
                    SET status = ?,
                        error_message = CASE WHEN ? != '' THEN ? ELSE error_message END
                    WHERE id = ?
                    """,
                    (status, error_message, error_message, transfer_id),
                )
            conn.commit()
        finally:
            conn.close()

    def list_transfers(
        self,
        search_query: str = "",
        status_filter: str = "",
        direction_filter: str = "",
        sort_by: str = "date",
        sort_order: str = "desc",
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """Query transfers with search, filtering, and sorting."""
        query = "SELECT * FROM transfers WHERE 1=1"
        params: List[Any] = []

        if search_query:
            query += " AND (file_name LIKE ? OR peer_username LIKE ? OR peer_hostname LIKE ?)"
            wildcard = f"%{search_query}%"
            params.extend([wildcard, wildcard, wildcard])

        if status_filter:
            query += " AND status = ?"
            params.append(status_filter)

        if direction_filter:
            query += " AND direction = ?"
            params.append(direction_filter)

        # Map and sanitize sorting options to prevent SQL injection
        sort_column_map = {
            "date": "started_at",
            "name": "peer_username COLLATE NOCASE",
            "duration": "duration_seconds",
            "speed": "average_speed_mbps",
            "size": "total_bytes",
            "file": "file_name COLLATE NOCASE",
            "status": "status",
        }
        order_col = sort_column_map.get(sort_by.lower(), "started_at")
        direction_sql = "ASC" if str(sort_order).lower() == "asc" else "DESC"

        query += f" ORDER BY {order_col} {direction_sql}, started_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
        finally:
            conn.close()

    def record_research_metric(self, metric: Dict[str, Any]) -> None:
        """Store research comparison benchmark metrics."""
        sql = """
            INSERT INTO research_metrics (
                transfer_id, mode, file_size, total_time_seconds,
                avg_throughput_mbps, peak_throughput_mbps, chunk_size_min,
                chunk_size_max, chunk_size_final, total_chunks, retry_count,
                retransmitted_bytes, rtt_avg_ms, timestamp
            ) VALUES (
                :transfer_id, :mode, :file_size, :total_time_seconds,
                :avg_throughput_mbps, :peak_throughput_mbps, :chunk_size_min,
                :chunk_size_max, :chunk_size_final, :total_chunks, :retry_count,
                :retransmitted_bytes, :rtt_avg_ms, :timestamp
            )
        """
        conn = self._get_connection()
        try:
            conn.execute(sql, metric)
            conn.commit()
        finally:
            conn.close()

    def get_research_metrics(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Retrieve recent research experiment records."""
        conn = self._get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM research_metrics ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]
        finally:
            conn.close()
