import os
from pathlib import Path
import tempfile
import pytest

from backend.config import AppConfig, get_pc_name, get_local_ip


def test_hostname_and_ip_detected():
    hostname = get_pc_name()
    assert len(hostname) > 0
    ip = get_local_ip()
    assert len(ip) > 0


def test_config_persistence_in_custom_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        cfg1 = AppConfig(custom_app_data_dir=tmp_path)

        # Initial state
        assert cfg1.username == ""
        assert len(cfg1.device_id) > 10
        initial_device_id = cfg1.device_id

        # Set username
        cfg1.set_username("Devraj-Test")
        assert cfg1.username == "Devraj-Test"

        # Reload from same app data dir
        cfg2 = AppConfig(custom_app_data_dir=tmp_path)
        assert cfg2.username == "Devraj-Test"
        assert cfg2.device_id == initial_device_id  # Device ID must be reused!
        assert cfg2.to_dict()["has_configured_user"] is True


def test_download_dir_not_in_project_folder():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        cfg = AppConfig(custom_app_data_dir=tmp_path)
        project_root = Path(__file__).resolve().parent.parent

        # Verify default download dir is not inside project root
        assert not str(cfg.download_dir.resolve()).startswith(str(project_root.resolve()))

        # Verify custom download dir
        custom_dl = tmp_path / "MyCustomDownloads"
        cfg.set_download_dir(custom_dl)
        assert cfg.download_dir == custom_dl
        assert custom_dl.exists()
