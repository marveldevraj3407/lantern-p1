import hashlib
from pathlib import Path
import tempfile
import pytest

from backend.models import FileItem
from backend.transfer.resume import PartialTransferSession


def test_partial_transfer_resume_and_verification():
    with tempfile.TemporaryDirectory() as tmpdir:
        base_path = Path(tmpdir)
        partial_dir = base_path / "partial"
        dl_dir = base_path / "downloads"
        dl_dir.mkdir()

        # Create original sample data (256 KB)
        sample_data = b"Smart-LAN-File-Sharing-Chunk-Data-" * 8000
        sample_size = len(sample_data)
        sample_sha = hashlib.sha256(sample_data).hexdigest()

        file_item = FileItem(relative_path="document.pdf", size=sample_size, sha256=sample_sha)

        # Session 1: Interrupted at 50%
        session1 = PartialTransferSession(
            transfer_id="tx_resume_test",
            partial_base_dir=partial_dir,
            download_base_dir=dl_dir,
            item_name="document.pdf",
            is_folder=False,
            files=[file_item],
        )

        half_size = sample_size // 2
        session1.write_chunk(file_index=0, offset=0, data=sample_data[:half_size])
        assert session1.get_resume_offset(0) == half_size

        # Session 2: Resume from interrupted offset
        session2 = PartialTransferSession(
            transfer_id="tx_resume_test",
            partial_base_dir=partial_dir,
            download_base_dir=dl_dir,
            item_name="document.pdf",
            is_folder=False,
            files=[file_item],
        )
        assert session2.get_resume_offset(0) == half_size

        # Write remaining half
        session2.write_chunk(file_index=0, offset=half_size, data=sample_data[half_size:])
        assert session2.get_resume_offset(0) == sample_size

        # Finalize and verify
        success, msg = session2.finalize_and_verify()
        assert success is True, msg

        final_file = dl_dir / "document.pdf"
        assert final_file.exists()
        assert final_file.stat().st_size == sample_size
        with open(final_file, "rb") as f:
            final_content = f.read()
        assert hashlib.sha256(final_content).hexdigest() == sample_sha
