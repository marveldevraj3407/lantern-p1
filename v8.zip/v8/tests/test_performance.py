import hashlib
from pathlib import Path
import tempfile
import threading
import time
import pytest

from backend.config import AppConfig
from backend.database import Database
from backend.models import FileItem, Peer
from backend.networking.tcp_client import TransferSender
from backend.networking.tcp_server import TCPServer
from backend.services.notification_service import NotificationBus
from backend.transfer.bandwidth import BandwidthController


def test_high_speed_streaming_throughput():
    """Verify that file streaming achieves high throughput without disk fsync bottlenecks."""
    with tempfile.TemporaryDirectory() as sender_tmp, tempfile.TemporaryDirectory() as receiver_tmp:
        sender_app_dir = Path(sender_tmp) / "appdata"
        receiver_app_dir = Path(receiver_tmp) / "appdata"

        receiver_dl = Path(receiver_tmp) / "downloads"
        receiver_dl.mkdir()

        cfg_receiver = AppConfig(custom_app_data_dir=receiver_app_dir)
        cfg_receiver.set_download_dir(receiver_dl)
        cfg_receiver.transfer_port = 50356

        db_receiver = Database(cfg_receiver.db_path)
        tcp_server = TCPServer(cfg_receiver, db_receiver, NotificationBus())
        tcp_server.start()

        # 10 MB payload
        payload_size = 10 * 1024 * 1024
        file_payload = b"X" * payload_size
        test_file = Path(sender_tmp) / "speed_test.bin"
        test_file.write_bytes(file_payload)
        file_sha = hashlib.sha256(file_payload).hexdigest()

        cfg_sender = AppConfig(custom_app_data_dir=sender_app_dir)
        db_sender = Database(cfg_sender.db_path)

        receiver_peer = Peer(
            device_id=cfg_receiver.device_id,
            username="Receiver-Bench",
            hostname="PC-Bench",
            ip="127.0.0.1",
            tcp_port=cfg_receiver.transfer_port,
        )

        transfer_id = "tx_throughput_test"
        sender = TransferSender(
            config=cfg_sender,
            database=db_sender,
            notifier=NotificationBus(),
            bandwidth_ctrl=BandwidthController(),
            transfer_id=transfer_id,
            peer=receiver_peer,
            source_path=test_file,
            item_name="speed_test.bin",
            is_folder=False,
            files=[FileItem(relative_path="speed_test.bin", size=payload_size, sha256=file_sha)],
            total_bytes=payload_size,
            priority="HIGH",
            is_adaptive=True,
        )

        def auto_accept():
            for _ in range(30):
                time.sleep(0.05)
                if tcp_server.resolve_pending_request(transfer_id, accept=True):
                    break

        threading.Thread(target=auto_accept, daemon=True).start()

        t_start = time.time()
        success = sender.run()
        tcp_server.stop()
        t_elapsed = time.time() - t_start

        assert success is True
        speed_mbps = (payload_size / (1024 * 1024)) / max(t_elapsed, 0.001)

        # Must transfer 10 MB in under 2 seconds (> 5 MB/s on loopback, typically 40-100 MB/s)
        assert speed_mbps >= 5.0

        # Verify integrity
        received_file = receiver_dl / "speed_test.bin"
        assert received_file.exists()
        assert received_file.stat().st_size == payload_size
        assert hashlib.sha256(received_file.read_bytes()).hexdigest() == file_sha


def test_adaptive_scaling_under_hotspot_latency():
    """Verify that AdaptiveEngine scales chunks above baseline under typical 30-50ms mobile hotspot RTT."""
    from backend.transfer.adaptive import AdaptiveEngine

    engine = AdaptiveEngine("tx_hotspot_test", is_adaptive=True)
    assert engine.get_next_chunk_size() == 64 * 1024

    # Simulate 8 successful chunk ACKs with 35ms mobile hotspot RTT
    for _ in range(8):
        current_chunk = engine.get_next_chunk_size()
        engine.record_chunk_ack(chunk_bytes=current_chunk, rtt_ms=35.0, success=True)

    final_chunk = engine.get_next_chunk_size()
    # Must have scaled up from 64KB to at least 1MB
    assert final_chunk >= 1024 * 1024
    assert engine.max_chunk_observed > 64 * 1024

    metrics = engine.generate_research_metrics(50 * 1024 * 1024)
    assert metrics["chunk_size_max"] >= 1024 * 1024
    assert len(metrics["decision_logs"]) >= 4


def test_adaptive_scaling_real_wifi_and_folder_tails():
    """Verify that AdaptiveEngine reaches 4MB chunks under real Wi-Fi serialization times and doesn't throttle on folder small files."""
    from backend.transfer.adaptive import AdaptiveEngine

    engine = AdaptiveEngine("tx_wifi_folder_test", is_adaptive=True)

    # Simulate realistic Wi-Fi transmission times as chunk size grows:
    # 64KB -> 30ms (2.1 MB/s)
    # 128KB -> 45ms (2.8 MB/s)
    # 256KB -> 65ms (3.9 MB/s)
    # 512KB -> 95ms (5.3 MB/s)
    # 1MB -> 140ms (7.3 MB/s)
    # 2MB -> 220ms (9.1 MB/s)
    # 4MB -> 320ms (12.5 MB/s)
    times = [30.0, 45.0, 65.0, 95.0, 140.0, 220.0, 320.0]
    for rtt in times:
        chunk = engine.get_next_chunk_size()
        engine.record_chunk_ack(chunk_bytes=chunk, rtt_ms=rtt, success=True)

    # Engine must have reached the maximum 4MB chunk size despite rtt_ms > 200ms
    assert engine.get_next_chunk_size() == 4 * 1024 * 1024

    # Now simulate a tiny 5KB file in a multi-file folder (e.g. config.ini in a game folder)
    # It takes 35ms hotspot latency, which has low instant throughput (0.14 MB/s)
    engine.record_chunk_ack(chunk_bytes=5 * 1024, rtt_ms=35.0, success=True)

    # Chunk size for the next file MUST still be retained at 4MB!
    assert engine.get_next_chunk_size() == 4 * 1024 * 1024

