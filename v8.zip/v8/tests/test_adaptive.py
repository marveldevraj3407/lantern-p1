import pytest
from backend.transfer.adaptive import AdaptiveEngine


def test_adaptive_scaling_and_congestion():
    engine = AdaptiveEngine("tx_test_123", is_adaptive=True)
    initial_chunk = engine.get_next_chunk_size()
    assert initial_chunk == 64 * 1024

    # Low latency stable ACKs -> should scale up chunk size
    for _ in range(5):
        engine.record_chunk_ack(chunk_bytes=initial_chunk, rtt_ms=5.0, success=True)

    scaled_chunk = engine.get_next_chunk_size()
    assert scaled_chunk > initial_chunk

    # Failure / drop -> should immediately throttle down
    engine.record_chunk_ack(chunk_bytes=scaled_chunk, rtt_ms=10.0, success=False)
    throttled_chunk = engine.get_next_chunk_size()
    assert throttled_chunk < scaled_chunk

    # High latency congestion -> should step down
    engine.record_chunk_ack(chunk_bytes=throttled_chunk, rtt_ms=250.0, success=True)
    congested_chunk = engine.get_next_chunk_size()
    assert congested_chunk <= throttled_chunk

    metrics = engine.generate_research_metrics(1024 * 1024)
    assert metrics["mode"] == "ADAPTIVE"
    assert metrics["retry_count"] == 1
    assert len(metrics["decision_logs"]) > 0


def test_baseline_fixed_mode():
    engine = AdaptiveEngine("tx_baseline_123", is_adaptive=False)
    assert engine.get_next_chunk_size() == 64 * 1024

    # Even with low RTT, size remains fixed
    for _ in range(5):
        engine.record_chunk_ack(chunk_bytes=64 * 1024, rtt_ms=2.0, success=True)

    assert engine.get_next_chunk_size() == 64 * 1024
    metrics = engine.generate_research_metrics(512 * 1024)
    assert metrics["mode"] == "BASELINE_FIXED"
