"""Tests package for L.A.N.T.E.R.N. (Local Area Network Transfer Engine for Rapid Networking)."""
