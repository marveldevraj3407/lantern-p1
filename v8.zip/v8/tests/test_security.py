from pathlib import Path
import tempfile
import pytest

from backend.transfer.security import sanitize_filename, resolve_safe_target_path


def test_sanitize_filename():
    assert sanitize_filename("../../passwords.txt") == "passwords.txt"
    assert sanitize_filename("C:\\Windows\\System32\\cmd.exe") == "cmd.exe"
    assert sanitize_filename("normal_file.pdf") == "normal_file.pdf"
    assert sanitize_filename("../../../") == "unnamed_file"


def test_resolve_safe_target_path():
    with tempfile.TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)

        # Normal file
        target = resolve_safe_target_path(base, "documents/report.pdf")
        assert str(target).startswith(str(base))
        assert target.name == "report.pdf"

        # Directory traversal attempt
        with pytest.raises(ValueError, match="Directory traversal detected"):
            resolve_safe_target_path(base, "../../escaped.txt")

        with pytest.raises(ValueError, match="Directory traversal detected"):
            resolve_safe_target_path(base, "sub/../../../escaped.txt")
