from pathlib import Path
import tempfile
import time
import pytest

from backend.config import AppConfig
from backend.networking.discovery import DiscoveryService
from backend.models import Peer


def test_discovery_peer_registry_and_timeout():
    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = AppConfig(custom_app_data_dir=Path(tmpdir))
        cfg.set_username("Devraj-A")

        updates = []
        discovery = DiscoveryService(cfg, on_peers_updated=lambda peers: updates.append(peers))

        # Simulate incoming peer announcement packet
        packet = {
            "type": "ANNOUNCE",
            "device_id": "remote-device-999",
            "username": "Rohan-B",
            "hostname": "Desktop-SK2B",
            "ip": "192.168.1.150",
            "tcp_port": 50056,
            "app_version": "2.0.0",
        }
        discovery._handle_incoming_packet(packet, "192.168.1.150")

        peers = discovery.get_peers()
        assert len(peers) == 1
        assert peers[0].device_id == "remote-device-999"
        assert peers[0].username == "Rohan-B"
        assert peers[0].is_online is True

        # Test local name check collision
        assert discovery.check_username_availability("Rohan-B") is False
        assert discovery.check_username_availability("AvailableUser") is True

        # Test timeout pruning
        peers[0].last_seen = time.time() - 15.0  # Expire peer
        discovery._prune_once()
        assert peers[0].is_online is False
        # Disconnected peer disappears completely from get_peers list
        assert len(discovery.get_peers()) == 0


def test_peer_goodbye_causes_peer_to_disappear():
    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = AppConfig(custom_app_data_dir=Path(tmpdir))
        cfg.set_username("Devraj-A")

        discovery = DiscoveryService(cfg)
        announce_pkt = {
            "type": "ANNOUNCE",
            "device_id": "peer-disconnect-123",
            "username": "Charlie",
            "hostname": "Charlie-PC",
            "ip": "192.168.1.180",
            "tcp_port": 50056,
        }
        discovery._handle_incoming_packet(announce_pkt, "192.168.1.180")
        assert len(discovery.get_peers()) == 1

        # Peer disconnects (sends GOODBYE)
        goodbye_pkt = {
            "type": "GOODBYE",
            "device_id": "peer-disconnect-123",
            "username": "Charlie",
        }
        discovery._handle_incoming_packet(goodbye_pkt, "192.168.1.180")

        # Disconnected peer must disappear from the list, not show as offline
        assert len(discovery.get_peers()) == 0
