from pathlib import Path
import tempfile
import pytest

from backend.app import create_app


@pytest.fixture
def client():
    with tempfile.TemporaryDirectory() as tmpdir:
        app = create_app(custom_app_data_dir=Path(tmpdir))
        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client
        # Clean up daemons
        try:
            app.discovery_obj.stop()
            app.tcp_server_obj.stop()
        except Exception:
            pass


def test_index_route(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"L.A.N.T.E.R.N." in res.data


def test_status_and_user_setup_flow(client):
    # Initial status - no username configured
    res = client.get("/api/status")
    assert res.status_code == 200
    data = res.get_json()
    assert data["config"]["has_configured_user"] is False

    # Setup username
    res_setup = client.post("/api/user/setup", json={"username": "Devraj"})
    assert res_setup.status_code == 200
    assert res_setup.get_json()["success"] is True

    # Status check after setup
    res2 = client.get("/api/status")
    data2 = res2.get_json()
    assert data2["config"]["has_configured_user"] is True
    assert data2["config"]["username"] == "Devraj"

    # Update username
    res_update = client.post("/api/user/update", json={"username": "Devraj-Pro"})
    assert res_update.status_code == 200
    assert res_update.get_json()["user"]["username"] == "Devraj-Pro"


def test_settings_endpoints(client):
    res = client.get("/api/settings")
    assert res.status_code == 200
    data = res.get_json()
    assert "download_dir" in data

    # Update settings
    res_post = client.post(
        "/api/settings",
        json={
            "default_priority": "HIGH",
            "bandwidth_limit_mbps": 10.5,
            "adaptive_mode": True,
        },
    )
    assert res_post.status_code == 200
    updated = res_post.get_json()["settings"]
    assert updated["default_priority"] == "HIGH"
    assert updated["bandwidth_limit_mbps"] == 10.5
