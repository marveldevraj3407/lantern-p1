import datetime
from pathlib import Path
import tempfile
import pytest

from backend.app import create_app
from backend.database import Database


@pytest.fixture
def test_setup():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        app = create_app(custom_app_data_dir=tmp_path)
        app.config["TESTING"] = True
        db = app.database_obj

        # Seed sample transfer records
        # 1. Sent to Alice (Outgoing) - 2026-10-20 10:00:00, 5 seconds, 10 MB/s
        db.record_transfer({
            "id": "tx_001",
            "direction": "OUTGOING",
            "peer_device_id": "dev_alice",
            "peer_username": "Alice",
            "peer_hostname": "PC-ALICE",
            "peer_ip": "192.168.1.101",
            "file_name": "ProjectReport.pdf",
            "relative_path": "",
            "is_folder": 0,
            "total_bytes": 50 * 1024 * 1024,
            "transferred_bytes": 50 * 1024 * 1024,
            "sha256": "abc123sha",
            "status": "COMPLETED",
            "priority": "HIGH",
            "error_message": "",
            "started_at": "2026-10-20T10:00:00",
            "completed_at": "2026-10-20T10:00:05",
            "duration_seconds": 5.0,
            "average_speed_mbps": 10.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 1,
        })

        # 2. Received from Bob (Incoming) - 2026-10-21 14:30:00, 2 seconds, 25 MB/s
        db.record_transfer({
            "id": "tx_002",
            "direction": "INCOMING",
            "peer_device_id": "dev_bob",
            "peer_username": "Bob",
            "peer_hostname": "PC-BOB",
            "peer_ip": "192.168.1.102",
            "file_name": "Dataset.zip",
            "relative_path": "",
            "is_folder": 0,
            "total_bytes": 50 * 1024 * 1024,
            "transferred_bytes": 50 * 1024 * 1024,
            "sha256": "def456sha",
            "status": "COMPLETED",
            "priority": "MEDIUM",
            "error_message": "",
            "started_at": "2026-10-21T14:30:00",
            "completed_at": "2026-10-21T14:30:02",
            "duration_seconds": 2.0,
            "average_speed_mbps": 25.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 1,
        })

        # 3. Sent to Charlie (Outgoing) - 2026-10-22 09:15:00, 12 seconds, 4 MB/s
        db.record_transfer({
            "id": "tx_003",
            "direction": "OUTGOING",
            "peer_device_id": "dev_charlie",
            "peer_username": "Charlie",
            "peer_hostname": "PC-CHARLIE",
            "peer_ip": "192.168.1.103",
            "file_name": "PhotosFolder",
            "relative_path": "",
            "is_folder": 1,
            "total_bytes": 48 * 1024 * 1024,
            "transferred_bytes": 48 * 1024 * 1024,
            "sha256": "",
            "status": "COMPLETED",
            "priority": "LOW",
            "error_message": "",
            "started_at": "2026-10-22T09:15:00",
            "completed_at": "2026-10-22T09:15:12",
            "duration_seconds": 12.0,
            "average_speed_mbps": 4.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 1,
        })

        with app.test_client() as client:
            yield {"db": db, "client": client, "app": app}

        try:
            app.discovery_obj.stop()
            app.tcp_server_obj.stop()
        except Exception:
            pass


def test_view_sender_and_receiver_details(test_setup):
    """Verify transfer history includes direction, peer name/hostname, date/time, duration, and speed."""
    db: Database = test_setup["db"]
    transfers = db.list_transfers()
    assert len(transfers) == 3

    # Check outgoing transfer (whom he sent the file to)
    tx_alice = next(t for t in transfers if t["id"] == "tx_001")
    assert tx_alice["direction"] == "OUTGOING"
    assert tx_alice["peer_username"] == "Alice"
    assert tx_alice["peer_hostname"] == "PC-ALICE"
    assert tx_alice["started_at"] == "2026-10-20T10:00:00"
    assert tx_alice["duration_seconds"] == 5.0
    assert tx_alice["average_speed_mbps"] == 10.0

    # Check incoming transfer (who sent the file to him)
    tx_bob = next(t for t in transfers if t["id"] == "tx_002")
    assert tx_bob["direction"] == "INCOMING"
    assert tx_bob["peer_username"] == "Bob"
    assert tx_bob["peer_hostname"] == "PC-BOB"
    assert tx_bob["started_at"] == "2026-10-21T14:30:00"
    assert tx_bob["duration_seconds"] == 2.0
    assert tx_bob["average_speed_mbps"] == 25.0


def test_sorting_by_peer_name(test_setup):
    """Verify sorting by sender or receiver name (A-Z and Z-A)."""
    db: Database = test_setup["db"]

    # Ascending: Alice, Bob, Charlie
    asc = db.list_transfers(sort_by="name", sort_order="asc")
    names_asc = [t["peer_username"] for t in asc]
    assert names_asc == ["Alice", "Bob", "Charlie"]

    # Descending: Charlie, Bob, Alice
    desc = db.list_transfers(sort_by="name", sort_order="desc")
    names_desc = [t["peer_username"] for t in desc]
    assert names_desc == ["Charlie", "Bob", "Alice"]


def test_sorting_by_date(test_setup):
    """Verify sorting by timestamp/date (newest first vs oldest first)."""
    db: Database = test_setup["db"]

    # Newest first (desc): Oct 22 (Charlie), Oct 21 (Bob), Oct 20 (Alice)
    newest = db.list_transfers(sort_by="date", sort_order="desc")
    ids_desc = [t["id"] for t in newest]
    assert ids_desc == ["tx_003", "tx_002", "tx_001"]

    # Oldest first (asc): Oct 20 (Alice), Oct 21 (Bob), Oct 22 (Charlie)
    oldest = db.list_transfers(sort_by="date", sort_order="asc")
    ids_asc = [t["id"] for t in oldest]
    assert ids_asc == ["tx_001", "tx_002", "tx_003"]


def test_sorting_by_duration_and_speed(test_setup):
    """Verify sorting by duration (time required) and average speed."""
    db: Database = test_setup["db"]

    # Fastest duration first (asc): 2.0s (Bob), 5.0s (Alice), 12.0s (Charlie)
    fastest = db.list_transfers(sort_by="duration", sort_order="asc")
    duration_asc = [t["duration_seconds"] for t in fastest]
    assert duration_asc == [2.0, 5.0, 12.0]

    # Highest speed first (desc): 25 MB/s (Bob), 10 MB/s (Alice), 4 MB/s (Charlie)
    highest_speed = db.list_transfers(sort_by="speed", sort_order="desc")
    speeds_desc = [t["average_speed_mbps"] for t in highest_speed]
    assert speeds_desc == [25.0, 10.0, 4.0]


def test_history_api_endpoints(test_setup):
    """Verify /api/transfers/history endpoint with sort and filter query parameters."""
    client = test_setup["client"]

    # 1. Default (date desc)
    res = client.get("/api/transfers/history")
    assert res.status_code == 200
    data = res.get_json()["transfers"]
    assert len(data) == 3
    assert data[0]["peer_username"] == "Charlie"

    # 2. Sort by name asc via API
    res = client.get("/api/transfers/history?sort_by=name&sort_order=asc")
    assert res.status_code == 200
    names = [t["peer_username"] for t in res.get_json()["transfers"]]
    assert names == ["Alice", "Bob", "Charlie"]

    # 3. Filter by direction: OUTGOING
    res = client.get("/api/transfers/history?direction=OUTGOING")
    assert res.status_code == 200
    outgoing = res.get_json()["transfers"]
    assert len(outgoing) == 2
    assert all(t["direction"] == "OUTGOING" for t in outgoing)

    # 4. Filter by direction: INCOMING
    res = client.get("/api/transfers/history?direction=INCOMING")
    assert res.status_code == 200
    incoming = res.get_json()["transfers"]
    assert len(incoming) == 1
    assert incoming[0]["peer_username"] == "Bob"
    assert incoming[0]["direction"] == "INCOMING"
