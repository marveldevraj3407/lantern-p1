import hashlib
from pathlib import Path
import tempfile
import threading
import time
import pytest

from backend.config import AppConfig
from backend.database import Database
from backend.models import FileItem, Peer
from backend.networking.tcp_client import TransferSender
from backend.networking.tcp_server import TCPServer
from backend.services.notification_service import NotificationBus
from backend.transfer.bandwidth import BandwidthController


def test_pause_and_resume_transfer():
    with tempfile.TemporaryDirectory() as sender_tmp, tempfile.TemporaryDirectory() as receiver_tmp:
        sender_app_dir = Path(sender_tmp) / "appdata"
        receiver_app_dir = Path(receiver_tmp) / "appdata"
        receiver_dl = Path(receiver_tmp) / "downloads"
        receiver_dl.mkdir()

        cfg_receiver = AppConfig(custom_app_data_dir=receiver_app_dir)
        cfg_receiver.set_username("Receiver-PauseTest")
        cfg_receiver.set_download_dir(receiver_dl)
        cfg_receiver.transfer_port = 50256

        db_receiver = Database(cfg_receiver.db_path)
        notifier_receiver = NotificationBus()
        tcp_server = TCPServer(cfg_receiver, db_receiver, notifier_receiver)
        tcp_server.start()

        # Create a ~2MB test file so we have multiple chunks to pause and resume
        sender_files_dir = Path(sender_tmp) / "my_documents"
        sender_files_dir.mkdir()
        test_file = sender_files_dir / "large_dataset.bin"
        file_payload = b"0123456789ABCDEF" * 131072  # 2MB
        test_file.write_bytes(file_payload)
        file_size = len(file_payload)
        file_sha = hashlib.sha256(file_payload).hexdigest()

        cfg_sender = AppConfig(custom_app_data_dir=sender_app_dir)
        cfg_sender.set_username("Sender-PauseTest")
        db_sender = Database(cfg_sender.db_path)
        notifier_sender = NotificationBus()
        bw_ctrl = BandwidthController()

        receiver_peer = Peer(
            device_id=cfg_receiver.device_id,
            username="Receiver-PauseTest",
            hostname="PC-Receiver",
            ip="127.0.0.1",
            tcp_port=cfg_receiver.transfer_port,
        )

        transfer_id = "tx_pause_resume_001"
        sender = TransferSender(
            config=cfg_sender,
            database=db_sender,
            notifier=notifier_sender,
            bandwidth_ctrl=bw_ctrl,
            transfer_id=transfer_id,
            peer=receiver_peer,
            source_path=test_file,
            item_name="large_dataset.bin",
            is_folder=False,
            files=[FileItem(relative_path="large_dataset.bin", size=file_size, sha256=file_sha)],
            total_bytes=file_size,
            priority="MEDIUM",
            is_adaptive=False,
        )

        def auto_accept():
            for _ in range(30):
                time.sleep(0.05)
                if tcp_server.resolve_pending_request(transfer_id, accept=True):
                    break

        accept_thread = threading.Thread(target=auto_accept, daemon=True)
        accept_thread.start()

        # Thread that pauses the transfer after starting, waits, then resumes it
        def pause_resume_worker():
            # Wait until transfer has started transferring bytes
            for _ in range(50):
                time.sleep(0.02)
                if sender.transferred_bytes > 0:
                    break
            # Pause
            sender.pause()
            assert sender.is_paused is True
            time.sleep(0.3)
            # Resume
            sender.resume()
            assert sender.is_paused is False

        pr_thread = threading.Thread(target=pause_resume_worker, daemon=True)
        pr_thread.start()

        success = sender.run()
        pr_thread.join(timeout=2.0)
        tcp_server.stop()

        assert success is True
        received_file = receiver_dl / "large_dataset.bin"
        assert received_file.exists()
        assert received_file.stat().st_size == file_size
        assert hashlib.sha256(received_file.read_bytes()).hexdigest() == file_sha


def test_cancel_transfer():
    with tempfile.TemporaryDirectory() as sender_tmp, tempfile.TemporaryDirectory() as receiver_tmp:
        sender_app_dir = Path(sender_tmp) / "appdata"
        receiver_app_dir = Path(receiver_tmp) / "appdata"
        receiver_dl = Path(receiver_tmp) / "downloads"
        receiver_dl.mkdir()

        cfg_receiver = AppConfig(custom_app_data_dir=receiver_app_dir)
        cfg_receiver.set_username("Receiver-CancelTest")
        cfg_receiver.set_download_dir(receiver_dl)
        cfg_receiver.transfer_port = 50257

        db_receiver = Database(cfg_receiver.db_path)
        notifier_receiver = NotificationBus()
        tcp_server = TCPServer(cfg_receiver, db_receiver, notifier_receiver)
        tcp_server.start()

        sender_files_dir = Path(sender_tmp) / "my_documents"
        sender_files_dir.mkdir()
        test_file = sender_files_dir / "cancel_target.bin"
        file_payload = b"CancelTestBytePayloadStream" * 50000
        test_file.write_bytes(file_payload)
        file_size = len(file_payload)
        file_sha = hashlib.sha256(file_payload).hexdigest()

        cfg_sender = AppConfig(custom_app_data_dir=sender_app_dir)
        cfg_sender.set_username("Sender-CancelTest")
        db_sender = Database(cfg_sender.db_path)
        notifier_sender = NotificationBus()
        bw_ctrl = BandwidthController()

        receiver_peer = Peer(
            device_id=cfg_receiver.device_id,
            username="Receiver-CancelTest",
            hostname="PC-Receiver",
            ip="127.0.0.1",
            tcp_port=cfg_receiver.transfer_port,
        )

        transfer_id = "tx_cancel_001"
        sender = TransferSender(
            config=cfg_sender,
            database=db_sender,
            notifier=notifier_sender,
            bandwidth_ctrl=bw_ctrl,
            transfer_id=transfer_id,
            peer=receiver_peer,
            source_path=test_file,
            item_name="cancel_target.bin",
            is_folder=False,
            files=[FileItem(relative_path="cancel_target.bin", size=file_size, sha256=file_sha)],
            total_bytes=file_size,
            priority="HIGH",
            is_adaptive=False,
        )

        def auto_accept():
            for _ in range(30):
                time.sleep(0.05)
                if tcp_server.resolve_pending_request(transfer_id, accept=True):
                    break

        accept_thread = threading.Thread(target=auto_accept, daemon=True)
        accept_thread.start()

        def cancel_worker():
            for _ in range(50):
                time.sleep(0.02)
                if sender.transferred_bytes > 0:
                    break
            sender.cancel()

        c_thread = threading.Thread(target=cancel_worker, daemon=True)
        c_thread.start()

        success = sender.run()
        tcp_server.stop()
        time.sleep(0.3)

        # Cancellation should cause run() to return False
        assert success is False
        assert sender.is_cancelled is True
        tx_row = db_sender.get_transfer(transfer_id)
        assert tx_row["status"] == "CANCELLED"

