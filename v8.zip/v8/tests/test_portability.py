"""Portability and multi-PC data isolation test."""

from pathlib import Path
import tempfile
import pytest

from backend.config import AppConfig
from backend.database import Database


def test_independent_pc_installations_no_leakage():
    project_root = Path(__file__).resolve().parent.parent

    # Simulate PC A (e.g. Desktop-SK2A)
    with tempfile.TemporaryDirectory() as pc_a_root, tempfile.TemporaryDirectory() as pc_b_root:
        pc_a_appdata = Path(pc_a_root) / "AppData" / "Local" / "SmartLANFileShare"
        pc_b_appdata = Path(pc_b_root) / "AppData" / "Local" / "SmartLANFileShare"

        # Initialize PC A
        cfg_a = AppConfig(custom_app_data_dir=pc_a_appdata)
        cfg_a.set_username("Devraj-A")
        cfg_a.set_download_dir(Path(pc_a_root) / "Downloads" / "LAN Files")
        db_a = Database(cfg_a.db_path)
        db_a.record_transfer({
            "id": "tx_a_001",
            "direction": "OUTGOING",
            "peer_device_id": "remote-dev",
            "peer_username": "TargetUser",
            "peer_hostname": "TargetHost",
            "peer_ip": "192.168.1.100",
            "file_name": "Project_A.zip",
            "relative_path": "",
            "is_folder": 0,
            "total_bytes": 1024,
            "transferred_bytes": 1024,
            "sha256": "abc123",
            "status": "COMPLETED",
            "priority": "HIGH",
            "error_message": "",
            "started_at": "2026-09-09T10:00:00",
            "completed_at": "2026-09-09T10:00:05",
            "duration_seconds": 5.0,
            "average_speed_mbps": 2.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 1,
        })

        # Initialize PC B (e.g. Desktop-SK2B) - fresh copy of project
        cfg_b = AppConfig(custom_app_data_dir=pc_b_appdata)

        # Verification: PC B must NOT inherit PC A's identity
        assert cfg_b.username == ""
        assert cfg_b.device_id != cfg_a.device_id
        assert cfg_b.download_dir != cfg_a.download_dir

        db_b = Database(cfg_b.db_path)
        transfers_b = db_b.list_transfers()
        assert len(transfers_b) == 0  # No transfer history leakage!

        # Configure PC B independently
        cfg_b.set_username("Rohan-B")
        cfg_b.set_download_dir(Path(pc_b_root) / "CustomDownloads")
        assert cfg_b.username == "Rohan-B"

        # Verify nothing was written to project source tree
        assert not (project_root / "lan_share.db").exists()
        assert not (project_root / "config.json").exists()
        assert not (project_root / "storage").exists()
        assert not (project_root / "partial_transfers").exists()
