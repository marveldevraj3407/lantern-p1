import io
import pytest

from backend.networking.protocol import (
    encode_packet,
    decode_packet_from_socket,
    MAGIC,
    ProtocolError,
)


class MockSocket:
    def __init__(self, data: bytes = b""):
        self.stream = io.BytesIO(data)

    def recv(self, num_bytes: int) -> bytes:
        return self.stream.read(num_bytes)


def test_packet_encode_decode_roundtrip():
    header = {"type": "TRANSFER_REQUEST", "transfer_id": "test-123", "filename": "sample.bin"}
    payload = b"Hello Antigravity LAN File Sharing! 12345"

    encoded = encode_packet(header, payload)
    mock_sock = MockSocket(encoded)

    decoded_header, decoded_payload = decode_packet_from_socket(mock_sock)
    assert decoded_header["type"] == "TRANSFER_REQUEST"
    assert decoded_header["transfer_id"] == "test-123"
    assert decoded_header["filename"] == "sample.bin"
    assert decoded_header["payload_len"] == len(payload)
    assert decoded_payload == payload


def test_invalid_magic_raises_error():
    bad_prefix = b"XXXX" + (10).to_bytes(4, byteorder="big")
    mock_sock = MockSocket(bad_prefix)
    with pytest.raises(ProtocolError, match="Invalid magic bytes"):
        decode_packet_from_socket(mock_sock)
