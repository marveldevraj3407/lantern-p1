import hashlib
from pathlib import Path
import tempfile
import threading
import time
import pytest

from backend.config import AppConfig
from backend.database import Database
from backend.models import FileItem, Peer
from backend.networking.tcp_client import TransferSender
from backend.networking.tcp_server import TCPServer
from backend.services.notification_service import NotificationBus
from backend.transfer.bandwidth import BandwidthController


def test_end_to_end_tcp_file_transfer():
    with tempfile.TemporaryDirectory() as sender_tmp, tempfile.TemporaryDirectory() as receiver_tmp:
        sender_app_dir = Path(sender_tmp) / "appdata"
        receiver_app_dir = Path(receiver_tmp) / "appdata"

        receiver_dl = Path(receiver_tmp) / "downloads"
        receiver_dl.mkdir()

        cfg_receiver = AppConfig(custom_app_data_dir=receiver_app_dir)
        cfg_receiver.set_username("Bob-Receiver")
        cfg_receiver.set_download_dir(receiver_dl)
        cfg_receiver.transfer_port = 50156  # Dedicated test port

        db_receiver = Database(cfg_receiver.db_path)
        notifier_receiver = NotificationBus()
        tcp_server = TCPServer(cfg_receiver, db_receiver, notifier_receiver)
        tcp_server.start()

        # Create a test file for the sender
        sender_files_dir = Path(sender_tmp) / "my_documents"
        sender_files_dir.mkdir()
        test_file = sender_files_dir / "project_report.pdf"
        file_payload = b"Hello College Networks Project! P2P TCP socket streaming." * 1500
        test_file.write_bytes(file_payload)

        file_size = len(file_payload)
        file_sha = hashlib.sha256(file_payload).hexdigest()

        # Sender configuration
        cfg_sender = AppConfig(custom_app_data_dir=sender_app_dir)
        cfg_sender.set_username("Alice-Sender")
        db_sender = Database(cfg_sender.db_path)
        notifier_sender = NotificationBus()
        bw_ctrl = BandwidthController()

        receiver_peer = Peer(
            device_id=cfg_receiver.device_id,
            username="Bob-Receiver",
            hostname="PC-Bob",
            ip="127.0.0.1",
            tcp_port=cfg_receiver.transfer_port,
        )

        transfer_id = "tx_e2e_test_001"
        sender = TransferSender(
            config=cfg_sender,
            database=db_sender,
            notifier=notifier_sender,
            bandwidth_ctrl=bw_ctrl,
            transfer_id=transfer_id,
            peer=receiver_peer,
            source_path=test_file,
            item_name="project_report.pdf",
            is_folder=False,
            files=[FileItem(relative_path="project_report.pdf", size=file_size, sha256=file_sha)],
            total_bytes=file_size,
            priority="HIGH",
            is_adaptive=True,
        )

        # Background thread to simulate receiver UI clicking ACCEPT
        def auto_accept():
            for _ in range(30):
                time.sleep(0.1)
                if tcp_server.resolve_pending_request(transfer_id, accept=True):
                    break

        accept_thread = threading.Thread(target=auto_accept, daemon=True)
        accept_thread.start()

        # Run sender transfer
        success = sender.run()
        tcp_server.stop()

        assert success is True

        # Check receiver download folder
        received_file = receiver_dl / "project_report.pdf"
        assert received_file.exists()
        assert received_file.stat().st_size == file_size

        received_sha = hashlib.sha256(received_file.read_bytes()).hexdigest()
        assert received_sha == file_sha

        # Verify research metrics were recorded
        metrics = db_sender.get_research_metrics()
        assert len(metrics) >= 1
        assert metrics[0]["transfer_id"] == transfer_id


def test_dynamic_priority_switching():
    """Verify that priority can be changed mid-transfer Free Download Manager style."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = AppConfig(custom_app_data_dir=Path(tmpdir))
        db = Database(cfg.db_path)
        notifier = NotificationBus()
        bw_ctrl = BandwidthController()

        transfer_id = "tx_prio_test_01"
        sender = TransferSender(
            config=cfg,
            database=db,
            notifier=notifier,
            bandwidth_ctrl=bw_ctrl,
            transfer_id=transfer_id,
            peer=Peer(device_id="p1", username="Bob", hostname="PC", ip="127.0.0.1", tcp_port=5000),
            source_path="fake.txt",
            item_name="fake.txt",
            is_folder=False,
            files=[],
            total_bytes=1000,
            priority="MEDIUM",
        )

        # Initial registration in bandwidth controller
        bw_ctrl.register_transfer(transfer_id, "MEDIUM")
        assert bw_ctrl.get_priority(transfer_id) == "MEDIUM"

        # Record initial row in database
        db.record_transfer({
            "id": transfer_id,
            "direction": "OUTGOING",
            "peer_device_id": "p1",
            "peer_username": "Bob",
            "peer_hostname": "PC",
            "peer_ip": "127.0.0.1",
            "file_name": "fake.txt",
            "relative_path": "",
            "is_folder": 0,
            "total_bytes": 1000,
            "transferred_bytes": 100,
            "sha256": "",
            "status": "IN_PROGRESS",
            "priority": "MEDIUM",
            "error_message": "",
            "started_at": "2026-10-22T10:00:00",
            "completed_at": None,
            "duration_seconds": 1.0,
            "average_speed_mbps": 1.0,
            "retry_count": 0,
            "resumed": 0,
            "integrity_verified": 0,
        })

        sub_q = notifier.subscribe()

        # User changes priority to HIGH mid-transfer
        assert sender.set_priority("HIGH") is True
        assert sender.priority == "HIGH"
        assert bw_ctrl.get_priority(transfer_id) == "HIGH"

        rec = db.get_transfer(transfer_id)
        assert rec is not None
        assert rec["priority"] == "HIGH"

        # User changes priority to LOW mid-transfer
        assert sender.set_priority("LOW") is True
        assert sender.priority == "LOW"
        assert bw_ctrl.get_priority(transfer_id) == "LOW"

        rec = db.get_transfer(transfer_id)
        assert rec["priority"] == "LOW"

        # Verify notifications were fired
        evt1 = sub_q.get_nowait()
        assert evt1["event"] == "TRANSFER_PRIORITY_UPDATED"
        assert evt1["data"]["priority"] == "HIGH"

        evt2 = sub_q.get_nowait()
        assert evt2["event"] == "TRANSFER_PRIORITY_UPDATED"
        assert evt2["data"]["priority"] == "LOW"
